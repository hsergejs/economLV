-- phpMyAdmin SQL Dump
-- version 2.11.9.5
-- http://www.phpmyadmin.net
--
-- Host: 172.16.4.203
-- Generation Time: Apr 14, 2011 at 05:23 PM
-- Server version: 5.0.83
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db1036637_econom`
--

-- --------------------------------------------------------

--
-- Table structure for table `catalogue_lat`
--

CREATE TABLE IF NOT EXISTS `catalogue_lat` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `ltd_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `city` varchar(25) collate utf8_unicode_ci NOT NULL,
  `b_def` varchar(45) collate utf8_unicode_ci NOT NULL,
  `definition` varchar(45) collate utf8_unicode_ci NOT NULL,
  `activation` enum('0','1','2') collate utf8_unicode_ci NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ltd_name` (`ltd_name`),
  KEY `login` (`login`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `catalogue_lat`
--

INSERT INTO `catalogue_lat` (`id`, `login`, `ltd_name`, `city`, `b_def`, `definition`, `activation`) VALUES
(1, 'info@f-lux.lv', 'Fluks', 'Rīga', 'Internetveikali', 'Bižutērija', '2'),
(9, 'alexunco@gmail.com', 'Alex and Co', 'Jūrmala', 'Skaistums un veselība', 'Aprīkojums, piederumi', '1'),
(8, 'info@spaschool.lv', 'Spa School', 'Rīga', 'Izglītība', 'Mācību iestādes', '1'),
(14, 'maha21@inbox.lv', 'pohudei.lv', 'Rīga', 'Skaistums un veselība', 'Citi', '1'),
(17, 'info@travelservice.lv', 'Travel Service', 'Rīga', 'Tūrisms', 'Tūrisma aģentūra', '1'),
(20, 'natalija.brenca@balticom.lv', 'Brench Photography', 'Rīga', 'Kāzām', 'Foto, video pakalpojumi', '1'),
(22, 'info@agalmo.lv', 'Agalmo', 'Rīga', 'Citi', 'Tulkojumi', '1'),
(23, 'info@nightangel.lv', 'Night-Angel', 'Rīga', 'Apģērbs', 'Apakšveļa', '2'),
(24, 'meriden1@inbox.lv', 'Somashop', 'Rīga', 'Internetveikali', 'Apģērbs', '2'),
(25, 'bmw6666@inbox.lv', 'jbrasari', 'Valka un raj', 'Atpūta un izklaide', 'Kompjūterspēles un videospēles', '1');

-- --------------------------------------------------------

--
-- Table structure for table `catalogue_rus`
--

CREATE TABLE IF NOT EXISTS `catalogue_rus` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `ltd_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `city` varchar(25) collate utf8_unicode_ci NOT NULL,
  `b_def` varchar(45) collate utf8_unicode_ci NOT NULL,
  `definition` varchar(45) collate utf8_unicode_ci NOT NULL,
  `activation` enum('0','1','2') collate utf8_unicode_ci NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ltd_name` (`ltd_name`),
  KEY `login` (`login`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `catalogue_rus`
--

INSERT INTO `catalogue_rus` (`id`, `login`, `ltd_name`, `city`, `b_def`, `definition`, `activation`) VALUES
(1, 'info@f-lux.lv', 'Fluks', 'Рига', 'Интернет магазин', 'Бижутерия', '2'),
(9, 'alexunco@gmail.com', 'Alex and Co', 'Юрмала', 'Красота и здоровье', 'Оборудование, приборы', '1'),
(8, 'info@spaschool.lv', 'Spa School', 'Рига', 'Образовaние', 'Учебые заведния', '1'),
(14, 'maha21@inbox.lv', 'pohudei.lv', 'Рига', 'Красота и здоровье', 'Другое', '1'),
(17, 'info@travelservice.lv', 'Travel Service', 'Рига', 'Туризм', 'Туристическое агенство', '1'),
(20, 'natalija.brenca@balticom.lv', 'Brench Photography', 'Рига', 'Для свадьбы', 'Фото, Видео услуги', '1'),
(22, 'info@agalmo.lv', 'Agalmo', 'Рига', 'Другое', 'Переводы', '1'),
(23, 'info@nightangel.lv', 'Night-Angel', 'Рига', 'Одежда', 'Нижнее белье', '2'),
(24, 'meriden1@inbox.lv', 'Somashop', 'Рига', 'Интернет магазин', 'Одежда', '2'),
(25, 'bmw6666@inbox.lv', 'jbrasari', 'Валка и р-он', 'Отдых и развлечения', 'Компьютерные и видеоигры', '1');

-- --------------------------------------------------------

--
-- Table structure for table `cat_create_lat`
--

CREATE TABLE IF NOT EXISTS `cat_create_lat` (
  `b_def` varchar(45) collate utf8_unicode_ci NOT NULL,
  `def` varchar(45) collate utf8_unicode_ci NOT NULL,
  KEY `b_def` (`b_def`,`def`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cat_create_lat`
--

INSERT INTO `cat_create_lat` (`b_def`, `def`) VALUES
('Aksesuāri', 'Bižutērija'),
('Aksesuāri', 'Citi'),
('Aksesuāri', 'Juvelierizstrādājumi'),
('Aksesuāri', 'Pakalpojumi'),
('Aksesuāri', 'Pulksteņi'),
('Apavi', 'Citi'),
('Apavi', 'Darbam'),
('Apavi', 'Pakalpojumi'),
('Apavi', 'Sieviešu'),
('Apavi', 'Vīriešu'),
('Apdrošināšana', 'Auto'),
('Apdrošināšana', 'Citi'),
('Apdrošināšana', 'Nekustamais īpašums'),
('Apdrošināšana', 'Pakalpojumi'),
('Apdrošināšana', 'Tūrisms'),
('Apdrošināšana', 'Veselība'),
('Apģērbs', 'Aksesuāri'),
('Apģērbs', 'Apakšveļa'),
('Apģērbs', 'Citi'),
('Apģērbs', 'Darbam'),
('Apģērbs', 'Pakalpojumi'),
('Apģērbs', 'Peldkostīmi'),
('Apģērbs', 'Sieviešu'),
('Apģērbs', 'Vīriešu'),
('Atpūta un izklaide', 'Atrakcijas'),
('Atpūta un izklaide', 'Baseini'),
('Atpūta un izklaide', 'Cirks'),
('Atpūta un izklaide', 'Citi'),
('Atpūta un izklaide', 'Grāmatas, žurnāli, mūzika'),
('Atpūta un izklaide', 'Kompjūterspēles un videospēles'),
('Atpūta un izklaide', 'Koncerti'),
('Atpūta un izklaide', 'Medības, zveja'),
('Atpūta un izklaide', 'Nakts klubi'),
('Atpūta un izklaide', 'Pakalpojumi'),
('Atpūta un izklaide', 'Pirotehnika'),
('Atpūta un izklaide', 'Pirts'),
('Atpūta un izklaide', 'Svinību rīkošana, vadīšana'),
('Atpūta un izklaide', 'Teātri'),
('Atpūta un izklaide', 'Telpu noformēšana'),
('Bērniem', 'Aksesuāri'),
('Bērniem', 'Apavi'),
('Bērniem', 'Apģērbs'),
('Bērniem', 'Bērna kopšanai'),
('Bērniem', 'Citi'),
('Bērniem', 'Dāvanas'),
('Bērniem', 'Māmiņām'),
('Bērniem', 'Mēbeles'),
('Bērniem', 'Nometnes'),
('Bērniem', 'Pakalpojumi'),
('Bērniem', 'Pasākumi'),
('Bērniem', 'Pasākumu vadīšana, rīkošana'),
('Bērniem', 'Ratiņi, somas, autokrēsli'),
('Bērniem', 'Rotaļlietas, spēles'),
('Bērniem', 'Skolai'),
('Celtniecība un remonts', 'Apavi'),
('Celtniecība un remonts', 'Apģērbs'),
('Celtniecība un remonts', 'Būvmateriāli'),
('Celtniecība un remonts', 'Būvniecības darbi'),
('Celtniecība un remonts', 'Citi'),
('Celtniecība un remonts', 'Instrumenti un tehnika'),
('Celtniecība un remonts', 'Pakalpojumi'),
('Celtniecība un remonts', 'Projekti, dizains'),
('Celtniecība un remonts', 'Vārti, žalūzijas, durvis, logi'),
('Citi', 'Citi'),
('Citi', 'Detektīvu aģentūra'),
('Citi', 'Foto, video pakalpojumi'),
('Citi', 'Ķīmiskā tīrīšana'),
('Citi', 'Pakalpojumi'),
('Citi', 'Tulkojumi'),
('Dzīvnieki, putni, zivis', 'Citi'),
('Dzīvnieki, putni, zivis', 'Eksotiskie dzīvnieki'),
('Dzīvnieki, putni, zivis', 'Mājdzīvnieki, putni, zivis'),
('Dzīvnieki, putni, zivis', 'Pakalpojums'),
('Dzīvnieki, putni, zivis', 'Preces dzīvniekiem'),
('Dzīvnieki, putni, zivis', 'Veterinārārsts'),
('Elektronika un tehnika', 'Aksesuāri'),
('Elektronika un tehnika', 'Audio tehnika'),
('Elektronika un tehnika', 'Citi'),
('Elektronika un tehnika', 'Datori'),
('Elektronika un tehnika', 'Foto un optika'),
('Elektronika un tehnika', 'Mobilie tālruņi'),
('Elektronika un tehnika', 'Pakalpojumi'),
('Elektronika un tehnika', 'TV, video, DVD'),
('Elektronika un tehnika', 'Virtuves tehnika'),
('Finansu pakalpojumi', 'Banku pakalpojumi'),
('Finansu pakalpojumi', 'Citi'),
('Finansu pakalpojumi', 'Ekspertīzes un novērtējums'),
('Finansu pakalpojumi', 'Grāmatvedības pakalpojumi'),
('Finansu pakalpojumi', 'Juridiskie pakalpojumi'),
('Finansu pakalpojumi', 'Līzings, kredīti'),
('Internets, radio, televīzija, sakari', 'Citi'),
('Internets, radio, televīzija, sakari', 'Internets'),
('Internets, radio, televīzija, sakari', 'Pakalpojumi'),
('Internets, radio, televīzija, sakari', 'Radio'),
('Internets, radio, televīzija, sakari', 'Reklāma'),
('Internets, radio, televīzija, sakari', 'Sakari'),
('Internets, radio, televīzija, sakari', 'Televīzija'),
('Internetveikali', 'Apavi'),
('Internetveikali', 'Apģērbs'),
('Internetveikali', 'Auto rezerves daļas'),
('Internetveikali', 'Bižutērija'),
('Internetveikali', 'Būvmateriāli'),
('Internetveikali', 'Citi'),
('Internetveikali', 'Elektronika un tehnika'),
('Internetveikali', 'Grāmatas, žurnāli, mūzika'),
('Internetveikali', 'Juvelierizstrādājumi'),
('Internetveikali', 'Kancelejas preces'),
('Internetveikali', 'Kompjūterspēles un videospēles'),
('Internetveikali', 'Kosmētika'),
('Internetveikali', 'Mājai'),
('Internetveikali', 'Medikamenti'),
('Internetveikali', 'Ofisam'),
('Internetveikali', 'Parfimērija'),
('Internetveikali', 'Pirotehnika'),
('Internetveikali', 'Preces dzīvniekiem'),
('Internetveikali', 'Pulksteņi'),
('Internetveikali', 'Ziedi'),
('Izglītība', 'Autoskolas'),
('Izglītība', 'Citi'),
('Izglītība', 'Grāmatas'),
('Izglītība', 'Kursi'),
('Izglītība', 'Mācību iestādes'),
('Kāzām', 'Aksesuāri'),
('Kāzām', 'Apavi'),
('Kāzām', 'Apģērbs'),
('Kāzām', 'Audio pavadījums'),
('Kāzām', 'Citi'),
('Kāzām', 'Foto, video pakalpojumi'),
('Kāzām', 'Frizieris'),
('Kāzām', 'Jokdaris, viesu izklaidētājs'),
('Kāzām', 'Pirotehnika'),
('Kāzām', 'Salons'),
('Kāzām', 'Stilists'),
('Kāzām', 'Telpas'),
('Kāzām', 'Telpu noformējums'),
('Kāzām', 'Transports'),
('Kāzām', 'Vakara vadītājs'),
('Kāzām', 'Ziedi'),
('Nekustamais īpašums', 'Citi'),
('Nekustamais īpašums', 'Dzīvokļi'),
('Nekustamais īpašums', 'Garāžas, stāvvietas'),
('Nekustamais īpašums', 'Mājas, vasarnīcas'),
('Nekustamais īpašums', 'Ofisi, telpas'),
('Nekustamais īpašums', 'Pakalpojumi'),
('Nekustamais īpašums', 'Zeme, mežs'),
('Ofisam, mājai un dārzam', 'Aksesuāri'),
('Ofisam, mājai un dārzam', 'Apgaismojums'),
('Ofisam, mājai un dārzam', 'Apģērbs un apavi dārzam'),
('Ofisam, mājai un dārzam', 'Augi, ziedi, krūmāji'),
('Ofisam, mājai un dārzam', 'Citi'),
('Ofisam, mājai un dārzam', 'Degviela, kurināmais'),
('Ofisam, mājai un dārzam', 'Instrumenti, aprīkojums'),
('Ofisam, mājai un dārzam', 'Kancelejas preces'),
('Ofisam, mājai un dārzam', 'Mājsaimniecībai'),
('Ofisam, mājai un dārzam', 'Mēbeles dārzam'),
('Ofisam, mājai un dārzam', 'Mēbeles mājai'),
('Ofisam, mājai un dārzam', 'Mēbeles ofisam'),
('Ofisam, mājai un dārzam', 'Pakalpojumi'),
('Ofisam, mājai un dārzam', 'Santehnika, apkures sistēmas'),
('Ofisam, mājai un dārzam', 'Trauki un piederumi'),
('Ofisam, mājai un dārzam', 'Zīmogi, spiedogi, plombes'),
('Pārtikas produkti', 'Augļi'),
('Pārtikas produkti', 'Citi'),
('Pārtikas produkti', 'Dārzeņi'),
('Pārtikas produkti', 'Dzērieni'),
('Pārtikas produkti', 'Pakalpojumi'),
('Pārtikas produkti', 'Produkti'),
('Poligrāfija un druka', 'Citi'),
('Poligrāfija un druka', 'Pakalpojumi'),
('Poligrāfija un druka', 'Poligrāfija un druka'),
('Restorāni un bāri', 'Bārs'),
('Restorāni un bāri', 'Citi'),
('Restorāni un bāri', 'Kafejnīca'),
('Restorāni un bāri', 'Pakalpojumi'),
('Restorāni un bāri', 'Restorāns'),
('Skaistums un veselība', 'Aprīkojums, piederumi'),
('Skaistums un veselība', 'Ārstniecība'),
('Skaistums un veselība', 'Citi'),
('Skaistums un veselība', 'Frizieris'),
('Skaistums un veselība', 'Kosmētika'),
('Skaistums un veselība', 'Masieris'),
('Skaistums un veselība', 'Medikamenti'),
('Skaistums un veselība', 'Parfimērija'),
('Skaistums un veselība', 'Skaistumkopšanas salons'),
('Skaistums un veselība', 'Solārijs'),
('Skaistums un veselība', 'SPA salons'),
('Skaistums un veselība', 'Stilists'),
('Sports', 'Aksesuāri'),
('Sports', 'Apavi'),
('Sports', 'Apģērbs'),
('Sports', 'Citi'),
('Sports', 'Inventārs'),
('Sports', 'Klubi'),
('Sports', 'Pakalpojumi'),
('Transports', 'Aksesuāri'),
('Transports', 'Apavi'),
('Transports', 'Apģērbs'),
('Transports', 'Autosaloni'),
('Transports', 'Autoservisi'),
('Transports', 'Citi'),
('Transports', 'Epikējums'),
('Transports', 'Īre'),
('Transports', 'Kravas auto un autobusi'),
('Transports', 'Lauksaimniecības tehnika'),
('Transports', 'Mototransports'),
('Transports', 'Pakalpojumi'),
('Transports', 'Pārvadājumi, krāvēji'),
('Transports', 'Rezerves daļas'),
('Transports', 'Ūdens transports'),
('Transports', 'Velotransports'),
('Transports', 'Vieglie auto'),
('Tūrisms', 'Aviobiļetes'),
('Tūrisms', 'Citi'),
('Tūrisms', 'Kempingi'),
('Tūrisms', 'Pakalpojumi'),
('Tūrisms', 'Pilsētas ekskursijas'),
('Tūrisms', 'Tūrisma aģentūra'),
('Tūrisms', 'Viesnīca'),
('Tūrisms', 'Viesu nams'),
('Web', 'Citi'),
('Web', 'Dizains'),
('Web', 'Hostings'),
('Web', 'Izstrāde'),
('Web', 'Katalogi'),
('Web', 'Reklāma'),
('Web', 'Sludinājumi'),
('Web', 'Sociālie tīkli');

-- --------------------------------------------------------

--
-- Table structure for table `cat_create_rus`
--

CREATE TABLE IF NOT EXISTS `cat_create_rus` (
  `b_def` varchar(45) collate utf8_unicode_ci NOT NULL,
  `def` varchar(45) collate utf8_unicode_ci NOT NULL,
  KEY `b_def` (`b_def`,`def`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cat_create_rus`
--

INSERT INTO `cat_create_rus` (`b_def`, `def`) VALUES
('Аксессуары', 'Бижутерия'),
('Аксессуары', 'Другое'),
('Аксессуары', 'Услуги'),
('Аксессуары', 'Часы'),
('Аксессуары', 'Ювелирные изделия'),
('Веб', 'Дизайн'),
('Веб', 'Другое'),
('Веб', 'Каталоги'),
('Веб', 'Обьявления'),
('Веб', 'Разработка'),
('Веб', 'Реклама'),
('Веб', 'Соц сети'),
('Веб', 'Хостинг'),
('Для детей', 'Аксессуары'),
('Для детей', 'Для мамочек'),
('Для детей', 'Для ухода за ребенком'),
('Для детей', 'Для школы'),
('Для детей', 'Другое'),
('Для детей', 'Игрушки, игры'),
('Для детей', 'Коляски, сумки, автокресла'),
('Для детей', 'Лагерь'),
('Для детей', 'Мебель'),
('Для детей', 'Мероприятия'),
('Для детей', 'Обувь'),
('Для детей', 'Одежда'),
('Для детей', 'Подарки'),
('Для детей', 'Проведение праздников'),
('Для детей', 'Услуги'),
('Для офиса, дома и сада', 'Аксессуары'),
('Для офиса, дома и сада', 'Для домашнего хозяйства'),
('Для офиса, дома и сада', 'Другое'),
('Для офиса, дома и сада', 'Инструменты, оборудование'),
('Для офиса, дома и сада', 'Канцелярия'),
('Для офиса, дома и сада', 'Мебель для дома'),
('Для офиса, дома и сада', 'Мебель для офиса'),
('Для офиса, дома и сада', 'Мебель для сада'),
('Для офиса, дома и сада', 'Одежда и обувь для сада'),
('Для офиса, дома и сада', 'Осветительное оборудование'),
('Для офиса, дома и сада', 'Печати, штампы, пломбы'),
('Для офиса, дома и сада', 'Посуда и принадлежности'),
('Для офиса, дома и сада', 'Растения, цветы, саженцы'),
('Для офиса, дома и сада', 'Сантехника, отопительное оборудование'),
('Для офиса, дома и сада', 'Топливо, дрова'),
('Для офиса, дома и сада', 'Услуги'),
('Для свадьбы', 'Аксессуары'),
('Для свадьбы', 'Аудио сопровождение'),
('Для свадьбы', 'Другое'),
('Для свадьбы', 'Обувь'),
('Для свадьбы', 'Одежда'),
('Для свадьбы', 'Парихмахер'),
('Для свадьбы', 'Пиротехника'),
('Для свадьбы', 'Помещение'),
('Для свадьбы', 'Салон'),
('Для свадьбы', 'Стилист'),
('Для свадьбы', 'Тамода'),
('Для свадьбы', 'Транспорт'),
('Для свадьбы', 'Украшение помещений'),
('Для свадьбы', 'Фокусник'),
('Для свадьбы', 'Фото, Видео услуги'),
('Для свадьбы', 'Цветы'),
('Другое', 'Детективное агенство'),
('Другое', 'Другое'),
('Другое', 'Переводы'),
('Другое', 'Услуги'),
('Другое', 'Фото, Видео услуги'),
('Другое', 'Хим чистка'),
('Животные, птицы и pыбы', 'Ветеринар'),
('Животные, птицы и pыбы', 'Домашние животные, птицы, pыбы'),
('Животные, птицы и pыбы', 'Другое'),
('Животные, птицы и pыбы', 'Товары для животных'),
('Животные, птицы и pыбы', 'Услуги'),
('Животные, птицы и pыбы', 'Экзотические животные'),
('Интернет магазин', 'Автозапчасти'),
('Интернет магазин', 'Бижутерия'),
('Интернет магазин', 'Для дома'),
('Интернет магазин', 'Для офиса'),
('Интернет магазин', 'Другое'),
('Интернет магазин', 'Канцелярия'),
('Интернет магазин', 'Книги, журналы, музыка'),
('Интернет магазин', 'Компьютерные и видеоигры'),
('Интернет магазин', 'Косметика'),
('Интернет магазин', 'Медикaменты'),
('Интернет магазин', 'Обувь'),
('Интернет магазин', 'Одежда'),
('Интернет магазин', 'Парфюмерия'),
('Интернет магазин', 'Пиротехника'),
('Интернет магазин', 'Стройматериалы'),
('Интернет магазин', 'Товары для животных'),
('Интернет магазин', 'Цветы'),
('Интернет магазин', 'Часы'),
('Интернет магазин', 'Электроника и техника'),
('Интернет магазин', 'Ювелирные изделия'),
('Интернет, радио, телевидение, связь', 'Другое'),
('Интернет, радио, телевидение, связь', 'Интернет'),
('Интернет, радио, телевидение, связь', 'Радио'),
('Интернет, радио, телевидение, связь', 'Реклама'),
('Интернет, радио, телевидение, связь', 'Связь'),
('Интернет, радио, телевидение, связь', 'Телевидение'),
('Интернет, радио, телевидение, связь', 'Услуги'),
('Красота и здоровье', 'Другое'),
('Красота и здоровье', 'Косметика'),
('Красота и здоровье', 'Лечение'),
('Красота и здоровье', 'Массажист'),
('Красота и здоровье', 'Медикоменты'),
('Красота и здоровье', 'Оборудование, приборы'),
('Красота и здоровье', 'Парихмахер'),
('Красота и здоровье', 'Парфюмерия'),
('Красота и здоровье', 'Салон красоты'),
('Красота и здоровье', 'Солярий'),
('Красота и здоровье', 'СПА салон'),
('Красота и здоровье', 'Стилист'),
('Недвижимость', 'Гаражи, стоянки'),
('Недвижимость', 'Дома, дачи'),
('Недвижимость', 'Другое'),
('Недвижимость', 'Земля, лес'),
('Недвижимость', 'Квартиры'),
('Недвижимость', 'Офисы, помещения'),
('Недвижимость', 'Услуги'),
('Образовaние', 'Автошколы'),
('Образовaние', 'Другое'),
('Образовaние', 'Книги'),
('Образовaние', 'Курсы'),
('Образовaние', 'Учебые заведния'),
('Обувь', 'Для работы'),
('Обувь', 'Другое'),
('Обувь', 'Женская'),
('Обувь', 'Мужская'),
('Обувь', 'Услуги'),
('Одежда', 'Аксессуары'),
('Одежда', 'Для работы'),
('Одежда', 'Другое'),
('Одежда', 'Женская'),
('Одежда', 'Купальные костюмы'),
('Одежда', 'Мужская'),
('Одежда', 'Нижнее белье'),
('Одежда', 'Услуги'),
('Отдых и развлечения', 'Атракционы'),
('Отдых и развлечения', 'Баня'),
('Отдых и развлечения', 'Бассеин'),
('Отдых и развлечения', 'Другое'),
('Отдых и развлечения', 'Книги, журналы, музыка'),
('Отдых и развлечения', 'Компьютерные и видеоигры'),
('Отдых и развлечения', 'Концерты'),
('Отдых и развлечения', 'Ночные клубы'),
('Отдых и развлечения', 'Охота, рыбалка'),
('Отдых и развлечения', 'Пиротехника'),
('Отдых и развлечения', 'Проведение торжеств'),
('Отдых и развлечения', 'Театры'),
('Отдых и развлечения', 'Украшение помещений'),
('Отдых и развлечения', 'Услуги'),
('Отдых и развлечения', 'Цирк'),
('Полиграфия и печать', 'Другое'),
('Полиграфия и печать', 'Полиграфия и печать'),
('Полиграфия и печать', 'Услуги'),
('Продукты питания', 'Другое'),
('Продукты питания', 'Напитки'),
('Продукты питания', 'Овощи'),
('Продукты питания', 'Продукты'),
('Продукты питания', 'Услуги'),
('Продукты питания', 'Фрукты'),
('Рестораны и бары', 'Бар'),
('Рестораны и бары', 'Другое'),
('Рестораны и бары', 'Кафе'),
('Рестораны и бары', 'Ресторан'),
('Рестораны и бары', 'Услуги'),
('Спорт', 'Аксессуары'),
('Спорт', 'Другое'),
('Спорт', 'Инвентарь'),
('Спорт', 'Клубы'),
('Спорт', 'Обувь'),
('Спорт', 'Одежда'),
('Спорт', 'Услуги'),
('Страхование', 'Авто '),
('Страхование', 'Другое'),
('Страхование', 'Здоровье'),
('Страхование', 'Недвижимость'),
('Страхование', 'Туризм'),
('Страхование', 'Услуги'),
('Строительство и ремонт', 'Ворота, жалюзи, двери, окна'),
('Строительство и ремонт', 'Другое'),
('Строительство и ремонт', 'Инструменты и техника'),
('Строительство и ремонт', 'Обувь'),
('Строительство и ремонт', 'Одежда'),
('Строительство и ремонт', 'Проекты, дизайн'),
('Строительство и ремонт', 'Сторительные работы'),
('Строительство и ремонт', 'Стройматериалы'),
('Строительство и ремонт', 'Услуги'),
('Транспорт', 'Автосалон'),
('Транспорт', 'Автосервис'),
('Транспорт', 'Аксессуары'),
('Транспорт', 'Аренда'),
('Транспорт', 'Вело-транспорт'),
('Транспорт', 'Водный транспорт'),
('Транспорт', 'Грузовые авто и автобусы'),
('Транспорт', 'Другое'),
('Транспорт', 'Запчасти'),
('Транспорт', 'Легковые авто'),
('Транспорт', 'Мото-транспорт'),
('Транспорт', 'Обувь'),
('Транспорт', 'Одежда'),
('Транспорт', 'Перевозки, погрузка'),
('Транспорт', 'Сельхозтехника'),
('Транспорт', 'Услуги'),
('Транспорт', 'Экипировка'),
('Туризм', 'Авиобилеты'),
('Туризм', 'Городские туры'),
('Туризм', 'Дом для гостей'),
('Туризм', 'Другое'),
('Туризм', 'Кемпинг'),
('Туризм', 'Отель'),
('Туризм', 'Туристическое агенство'),
('Туризм', 'Услуги'),
('Финансовые услуги', 'Банковские услуги'),
('Финансовые услуги', 'Бухгалтерские услуги'),
('Финансовые услуги', 'Другое'),
('Финансовые услуги', 'Лизинг, Кредит'),
('Финансовые услуги', 'Экспертизы и оценка'),
('Финансовые услуги', 'Юридические услуги'),
('Электроника и техника', 'TV, видео, DVD'),
('Электроника и техника', 'Аксессуары'),
('Электроника и техника', 'Аудио техника'),
('Электроника и техника', 'Бытовая техника'),
('Электроника и техника', 'Другое'),
('Электроника и техника', 'Компьютеры'),
('Электроника и техника', 'Мобильные телефоны'),
('Электроника и техника', 'Услуги'),
('Электроника и техника', 'Фото и оптика');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `nick` varchar(20) collate utf8_unicode_ci NOT NULL,
  `avatar` varchar(35) collate utf8_unicode_ci NOT NULL,
  `message` text collate utf8_unicode_ci NOT NULL,
  `date` date NOT NULL default '0000-00-00',
  `time` time NOT NULL default '00:00:00',
  `sh_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `ip` varchar(15) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `login` (`login`),
  KEY `sh_name` (`sh_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `common_text_lat`
--

CREATE TABLE IF NOT EXISTS `common_text_lat` (
  `id` int(11) NOT NULL auto_increment,
  `meta_k` text collate utf8_unicode_ci NOT NULL,
  `meta_d` text collate utf8_unicode_ci NOT NULL,
  `title` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `text` text collate utf8_unicode_ci NOT NULL,
  `page` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `page` (`page`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `common_text_lat`
--

INSERT INTO `common_text_lat` (`id`, `meta_k`, `meta_d`, `title`, `text`, `page`) VALUES
(1, 'atlaižu, katalogs, atlaides, īpašie, piedāvājumi, akcijas, iepirkties, pievienojaties, bezmaksas, prece', 'Atlaižu katalogs econom.lv ir lieliska iespēja Jums atrast to, ko sirds vēlas par vēl labāku cenu!', 'Galvenā Econom.lv', 'echo "<h1 style=''font-family:Verdana, Geneva, sans-serif; font-size:15px; color:#666;''>Par mums</h1>\r\n<p style=''margin-bottom:70px''>Econom.lv ir lieliska iespēja Jums atrast to, ko sirds vēlas par vēl labāku cenu! Cenšamies uzturēt datu bāzē tikai jaunākos datus par pieejamajām atlaidēm un speciālajiem piedāvājumiem Latvijā.</p>\r\n\r\n<h3>Mūsu mērķis</h3>\r\n<p style=''margin-bottom:70px''>Mēs vēlamies Jums palīdzēt iepirkties un labi pavadīt brīvo laiku, vienlaicīgi ietaupot Jūsu līdzekļus un meklēšanas pūles.</p>\r\n\r\n<h3>Pievienojaties, tas ir bezmaksas!</h3>\r\n<p style=''margin-bottom:70px''>Jums ir prece vai pakalpojums ar atlaidi? Mēs būsim priecīgi Jums palīdzēt paziņot par tām jauniem un jau esošiem klientiem. Apmeklējiet sadaļu Ieeja/Reģistrācija un aizpildiet ļoti vienkāršu reģistrācijas formu, pēc kuras Jums būs iespēja izveidot savu personīgo lapu, kurā būs iespējams izvietot informāciju par Jūsu kompāniju, Jūsu akcijām un atlaidēm, kā arī sniegt iespēju esošajiem un topošajiem klientiem fotogrāfijas apskatīt savu preci , interjera salonu, klubu vai restorānu. <strong>Pievienojaties, tas ir BEZMAKSAS!</strong></p>";\r\n\r\n', 'index'),
(2, 'par mums, par kompāniju, par firmu, economlv, econom.lv, atlaides, īpašie piedāvājumi, zīmols, brends, skaistumkopšanas salons, viesnīca, ekstremālais sporta veids, atpūta, nakts klubs, diskotēka, kazino, spēļu zāle, spēļu automāti, produkti, veikali, preces, apavi, apģērbs, mode, elektronika, sadzīves preces, laptopi, portatīvie kompjūteri, fotogrāfijas, remonts, iekārtošana, pakalpojumi, tirdzniecības centrs, aksesuāri, mobilie telefoni, tulkojumi, kafejnīcas, cena, mēbeles, televizori, sakari, internets, spa, masāžas, frizūras.', 'Econom.lv ir lieliska iespēja Jums atrast to, ko sirds vēlas par vēl labāku cenu! Cenšamies uzturēt datu bāzē tikai jaunākos datus par pieejamajām atlaidēm un speciālajiem piedāvājumiem Rīgā.', 'Par projektu Econom.lv', 'echo "<h3>Par projektu Econom.lv</h3>\r\n<p><strong><a href=''index.php?lang=".$lang."''>www.econom.lv</a></strong> mājas lapa ir viena no progresējošākajām mājas lapām un ir unikāls Interneta pakalpojums Latvijā. Mēs piedāvājam strauju un augošu vidi, kura ļauj uzņēmumu savienot ar patērētāju. Pakalpojums, ko mēs piedāvājam ir paredzēts jebkura veida biznesam, ko var atrast tirgū. Ar mūsu palīdzību uzņēmumiem ir iespēja informēt dažādu interešu un vecuma patērētājus par saviem produktiem un pakalpojumiem, cenām, speciālajiem piedāvājumiem un atlaidēm. Mums ir divu veidu pakalpojumi - maksas un bezmaksas. Ar tiem Jūs varat iepazīties šajās saitēs: <a href=''join_us.php?lang=".$lang."''>Pievienoties (bezmaksas pakalpojumi)</a> un <a href=''advertising.php?lang=".$lang."''>Reklama (maksas pakalpojumi)</a>.</p>";', 'about_us'),
(3, 'Reklāma, baneris, attīstīšana, economlv, econom.lv, atlaides, īpašie piedāvājumi, zīmols, brends, skaistumkopšanas salons, viesnīca, ekstremālais sporta veids, atpūta, nakts klubs, diskotēka, kazino, spēļu zāle, spēļu automāti, produkti, veikali, preces, apavi, apģērbs, mode, elektronika, sadzīves preces, laptopi, portatīvie kompjūteri, fotogrāfijas, remonts, iekārtošana, pakalpojumi, tirdzniecības centrs, aksesuāri, mobilie telefoni, tulkojumi, kafejnīcas, cena, mēbeles, televizori, sakari, internets, spa, masāžas, frizūras.', 'Econom.lv ir lieliska iespēja Jums atrast to, ko sirds vēlas par vēl labāku cenu! Cenšamies uzturēt datu bāzē tikai jaunākos datus par pieejamajām atlaidēm un speciālajiem piedāvājumiem Rīgā.', 'Izvietojiet reklāmu pie mums', 'echo " <h3>Izvietojiet reklāmu pie mums</h3>\r\n<p>Econom.lv ir viena no visprogresējošākajām mājas lapām un ir unikāls serviss internetā un Latvijas tirgū. Sekojot līdzi masu mēdijiem, reklāma internetā ar katru gadu iegūst aizvien lielāku popularitāti Latvijas plašajā kompāniju lokā.<br>\r\nAr mūsu izdomu, oriģinālo piegājienu un individuālo pieeju katra mūsu klienta vēlmēm, mēs varam palīdzēt attīstīt Jūsu zīmolu.</p>\r\n\r\n<p><strong>Reklāmas produkti:</strong> Mūsu mājas lapā ir plašas izvēles iespējas reklāmas produkcijai, kuru Jūs varat izvietot pie mums, kā arī mēs nodrošinām uzņēmumu ar banera izveidošanu. (Ja Jūs interesē citu veidu produkti, kuri šeit nav pieminēti vai arī Jums ir nepieciešama papildus informācija, lūdzu nevilcinieties un kontaktējaties ar mums caur <a href=''contact_us.php?lang=".$lang."''>mājaslapā izvietotajiem kontaktiem</a>)</p>\r\n\r\n<p>Lielais baneris<br>\r\nVidējais baneris <br>\r\n''Esi zināms pateicoties zīmolam!''<br>\r\nGaleriju baneris<br>\r\nVideo baneris<br>\r\nDinamiskais baneris <br>\r\nPOP-UP/POP-UNDER baneris<br></p>";', 'advertising'),
(4, 'kontakti, kontaktinformācija, email, elektroniskais pasts, menedžeris, forma, economlv, econom.lv, atlaides, īpašie piedāvājumi, zīmols, brends, skaistumkopšanas salons, viesnīca, ekstremālais sporta veids, atpūta, nakts klubs, diskotēka, kazino, spēļu zāle, spēļu automāti, produkti, veikali, preces, apavi, apģērbs, mode, elektronika, sadzīves preces, laptopi, portatīvie kompjūteri, fotogrāfijas, remonts, iekārtošana, pakalpojumi, tirdzniecības centrs, aksesuāri, mobilie telefoni, tulkojumi, kafejnīcas, cena, mēbeles, televizori, sakari, internets, spa, masāžas, frizūras.', 'Econom.lv ir lieliska iespēja Jums atrast to, ko sirds vēlas par vēl labāku cenu! Cenšamies uzturēt datu bāzē tikai jaunākos datus par pieejamajām atlaidēm un speciālajiem piedāvājumiem Rīgā.', 'Kontaktinformācija', '<h3>Kontaktinformācija</h3>\r\n<p style=''margin-bottom:30px;''>Ja Jums ir kādas neskaidrības nekavējoties sazinieties ar mums:</p>', 'contact_us'),
(5, 'economlv, econom.lv, atlaides, īpašie piedāvājumi, zīmols, brends, skaistumkopšanas salons, viesnīca, ekstremālais sporta veids, atpūta, nakts klubs, diskotēka, kazino, spēļu zāle, spēļu automāti, produkti, veikali, preces, apavi, apģērbs, mode, elektronika, sadzīves preces, laptopi, portatīvie kompjūteri, fotogrāfijas, remonts, iekārtošana, pakalpojumi, tirdzniecības centrs, aksesuāri, mobilie telefoni, tulkojumi, kafejnīcas, cena, mēbeles, televizori, sakari, internets, spa, masāžas, frizūras.', 'Econom.lv ir lieliska iespēja Jums atrast to, ko sirds vēlas par vēl labāku cenu! Cenšamies uzturēt datu bāzē tikai jaunākos datus par pieejamajām atlaidēm un speciālajiem piedāvājumiem Rīgā.', 'Atbildības ierobežojums un Vienošanās', '<h3>Atbildības ierobežojums</h3>\r\n<p style=''margin-bottom:50px;''>Econom.lv ir informācijas resurss, mēs nereklamējam nevienu no veikaliem, preču zīmēm vai uzņēmumiem utt., ja bez iepriekš noslēgtas savstarpējās vienošanās.\r\nMēs centīsimies uzturēt šajā mājas lapā jaunāko informāciju, bet Econom.lv neuzņemas nekādu atbildību, ja kāda atlaide vai speciālais piedāvājums vairs nav spēkā vai ir mainīts tajā laikā, kad tā/tas ir uzrādīts un mēs neuzņemamies nekādu atbildību par kļūdām vai nolaidību, ko satur mūsu mājas lapa, Econom.lv rekomendē salīdzināt informāciju ar oficiālajiem avotiem. Ar šiem noteikumiem lietotājam jāsaprot, ka Econom.lv nesniedz piedāvājumus vai atlaides (ja nav kāda speciāla informācijas avota no mūsu mājas lapas administrācijas), bet tikai informāciju par tām.</p>\r\n\r\n\r\n<h3>&copy; Autortiesības</h3>\r\n<p style=''margin-bottom:50px;''>Viss Econom.lv mājas lapas saturs un dizains ir aizsargāts ar autortiesībām, jebkāda tā izmantošana bez atļaujas ir aizliegta.</p>\r\n\r\n\r\n<h3>Mūsu privātuma izmantošana noteikumi</h3>\r\n<p style=''margin-bottom:50px;''>Cookie faili: Daži skripti, kurus mēs izmantojam, iespējams, sūtīs cookie failus Jūsu datorā tikai statistikas veikšanai (t.i., mūsu sistēmas statistikai). Visa personīgā informācija (e-pasti, vārdi utt.), ko mēs saņemsim tiks izmantoti tikai un vienīgi Econom.lv vajadzībām un netiks pārdoti un/vai iemainīti, nodoti 3. personai.</p>\r\n\r\n\r\n<h3>Atsauksmes</h3>\r\n<p style=''margin-bottom:50px;''>Econom.lv neuzņemas nekādu atbildību par lietotāju atsauksmēm vai apskatiem, viedokļiem utt. Šo mājaslapas daļu aizbilda lietotājs. Mēs sekosim līdzi, lai novērstu neatbilstošu tekstu saturošus ierakstus, kā arī necenzētos tekstus.</p>\r\n\r\n\r\n<h3>Vienošanās</h3>\r\n<p style=''margin-bottom:50px;''>Econom.lv patur tiesības veikt jebkāda veida izmaiņas mājas lapā vai tās dizainā bez iepriekšējas brīdināšanas. Izmantojot saites vai banerus, kuri ir izvietoti šīs mājas lapas resursos, Jūs tiksiet pārsūtīti uz citu mājas lapu, kurai būs savi attiecīgie lietošanas noteikumi, Econom.lv nenes nekādu atbildību tiklīdz Jūs pārejat uz citu mājas lapu. Lietojot mūsu mājas lapu, lietotājs piekrīt ievērot mūsu autortiesības, lietošanas, vienošanās un citus noteikumus.</p>', 'disclaimer'),
(8, 'economlv, econom.lv, atlaides, īpašie piedāvājumi, zīmols, brends, skaistumkopšanas salons, viesnīca, ekstremālais sporta veids, atpūta, nakts klubs, diskotēka, kazino, spēļu zāle, spēļu automāti, produkti, veikali, preces, apavi, apģērbs, mode, elektronika, sadzīves preces, laptopi, portatīvie kompjūteri, fotogrāfijas, remonts, iekārtošana, pakalpojumi, tirdzniecības centrs, aksesuāri, mobilie telefoni, tulkojumi, kafejnīcas, cena, mēbeles, televizori, sakari, internets, spa, masāžas, frizūras, Par mums, par kompāniju, par firmu, Reklāma, baneris, attīstīšana, kontakti, kontaktinformācija, email, elektroniskais pasts, menedžeris, forma,  pievienojieties mums, katalogi, ekonomija', 'Econom.lv ir lieliska iespēja Jums atrast to, ko sirds vēlas par vēl labāku cenu! Cenšamies uzturēt datu bāzē tikai jaunākos datus par pieejamajām atlaidēm un speciālajiem piedāvājumiem Rīgā.', 'Katalogs', '', 'def_cat');

-- --------------------------------------------------------

--
-- Table structure for table `common_text_rus`
--

CREATE TABLE IF NOT EXISTS `common_text_rus` (
  `id` int(11) NOT NULL auto_increment,
  `meta_k` text collate utf8_unicode_ci NOT NULL,
  `meta_d` text collate utf8_unicode_ci NOT NULL,
  `title` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `text` text collate utf8_unicode_ci NOT NULL,
  `page` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `page` (`page`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `common_text_rus`
--

INSERT INTO `common_text_rus` (`id`, `meta_k`, `meta_d`, `title`, `text`, `page`) VALUES
(1, 'каталог, скидок, специальные, предложения, скидки, акции, покупки, товар, присоединяйтесь, бесплатно', 'Каталог скидок econom.lv - это отличная возможность найти то, что сердцу угодно за привлекательную цену!', 'Главная Econom.lv', 'echo "<h1 style=''font-family:Verdana, Geneva, sans-serif; font-size:15px; color:#666;''>О нас</h1>\r\n<p style=''margin-bottom:70px''>Econom.lv - это отличная возможность найти то, что сердцу угодно за привлекательную цену! В нашем каталоге Вы найдете информацию о  последних скидках  и специальных предложениях в Латвии, в удобном стиле и оформлении.</p>\r\n\r\n<h3>Наши цели</h3>\r\n<p style=''margin-bottom:70px''>Наша цель - помочь Вам хорошо провести выходные и порадовать себя покупками, не потратив лишних денег и времени на поиски.</p>\r\n\r\n<h3>Присоединяйтесь это бесплатно!</h3>\r\n<p style=''margin-bottom:70px''>У вас есть товар или услуга со скидкой? Мы будем рады помочь вам сообщить об этом новым и уже существующим клиентам. Посетите раздел Вход/Регистрация и пройдите простую регистрацию, после чего у вас будет возможность создания вашей личной страницы, на которой вы сможете расположить информацию о вас, о ваших акциях и скидках, а так же предоставить возможность просмотра фотографий вашего товара, интерьера салона, клуба или ресторана. <strong>Присоединяйтесь это БЕСПЛАТНО!</strong></p>";', 'index'),
(2, 'о нас, о фирме, о компании, economlv, econom.lv, скидки, специальные предложения, бренд, салон красоты, гостинница, экстремальный вид спорта, отдых, ночной клуб, дискотека, казино, продукты, магазины, товары, обувь, одежда, мода, электроника, лаптопы, компьютеры, фотографии, ремонт, обустройство, услуги, торговый центр, аксессуары, мобильные телефоны, переводы, кафе, цена, мебель, телевизоры, связь, интернет, спа, массаж, прически.', 'Econom.lv - это отличная возможность найти то, что сердцу угодно за привлекательную цену! В нашем каталоге Вы найдете информацию о  последних скидках  и специальных предложениях в Риге, в удобном стиле и оформлении.', 'О проекте Econom.lv', 'echo "<h3>О проекте Econom.lv</h3>    \r\n<p>Проект <strong><a href=''index.php?lang=".$lang."''>www.econom.lv</a></strong> – это один из наиболее прогрессивных и уникальный интернет-услуг на рынке Латвии. Наша команда создает возможность для соединения Потребителя и Предпринимателя в быстро развивающейся среде. Наши услуги могут подойти к любому типу бизнеса, который можно найти на рынке. С нашей помощью предприниматели могут информировать огромный круг существующих и потенциальных клиентов всевозможных возрастных групп и интересов о своих новых товарах или услугах, скидках и специальных предложениях. Мы предлагаем два типа услуг: <a href=''join_us.php?lang=".$lang."''>Бесплатные (раздел Присоединиться)</a> и <a href=''advertising.php?lang=".$lang."''>Платные (раздел Реклама)</a> вы можете ознакомиться с ними перейдя по необходимым ссылкам.</p>";', 'about_us'),
(7, 'реклама, баннер, продвижение, economlv, econom.lv, скидки, специальные предложения, бренд, салон красоты, гостинница, экстремальный вид спорта, отдых, ночной клуб, дискотека, казино, продукты, магазины, товары, обувь, одежда, мода, электроника, лаптопы, компьютеры, фотографии, ремонт, обустройство, услуги, торговый центр, аксессуары, мобильные телефоны, переводы, кафе, цена, мебель, телевизоры, связь, интернет, спа, массаж, прически.', 'Econom.lv - это отличная возможность найти то, что сердцу угодно за привлекательную цену! В нашем каталоге Вы найдете информацию о  последних скидках  и специальных предложениях в Риге, в удобном стиле и оформлении.', 'Реклама на Econom.lv', 'echo " <h3>Реклама на Econom.lv</h3>\r\n<p>Проект Econom.lv – это один из наиболее прогрессивных и уникальный интернет-услуг на рынке Латвии. Наряду с рекламой в СМИ, интернет-реклама год за годом получает всё большую и большую популярность среди фирм Латвии.<br>\r\nС нашими творческими идеями, оригинальными решениями и индивидуальным подходом к каждому из наших клиентов, мы сможем помочь Вам развивать и продвигать Ваш Бренд к новым вершинам.</p>\r\n\r\n<p><strong>Рекламная продукция:</strong> У нас имеется широкий выбор рекламной продукции, которую вы можете разместить на нашем сайте, а так же мы можем предоставить услуги по созданию баннерной рекламы. (Если Вас интересует какая-либо другая форма рекламы, не описанная ниже, или Вам нужна дополнительная информация, пожалуйста, свяжитесь с нами через <a href=''contact_us.php?lang=".$lang."''>раздел Контакты</a>)</p>\r\n\r\n<p>Мега баннер<br>\r\nСредний баннер<br>\r\n''Узнай меня по бренду!''<br>\r\nГалерея баннер, ротатор<br>\r\nВидео баннер<br>\r\nДинамический баннер<br>\r\nPOP-UP/POP-UNDER баннер<br></p>";', 'advertising'),
(4, 'контакты, контактная информация, емаил, електронная почта, менеджер, форма, economlv, econom.lv, скидки, специальные предложения, бренд, салон красоты, гостинница, экстремальный вид спорта, отдых, ночной клуб, дискотека, казино, продукты, магазины, товары, обувь, одежда, мода, электроника, лаптопы, компьютеры, фотографии, ремонт, обустройство, услуги, торговый центр, аксессуары, мобильные телефоны, переводы, кафе, цена, мебель, телевизоры, связь, интернет, спа, массаж, прически.', 'Econom.lv - это отличная возможность найти то, что сердцу угодно за привлекательную цену! В нашем каталоге Вы найдете информацию о  последних скидках  и специальных предложениях в Риге, в удобном стиле и оформлении.', 'Свяжитесь с нами', '<h3>Свяжитесь с нами</h3>\r\n<p style=''margin-bottom:30px;''>Если у Вас есть какие-либо вопросы, мы с радостью ответим на них:</p>', 'contact_us'),
(5, 'economlv, econom.lv, скидки, специальные предложения, бренд, салон красоты, гостинница, экстремальный вид спорта, отдых, ночной клуб, дискотека, казино, продукты, магазины, товары, обувь, одежда, мода, электроника, лаптопы, компьютеры, фотографии, ремонт, обустройство, услуги, торговый центр, аксессуары, мобильные телефоны, переводы, кафе, цена, мебель, телевизоры, связь, интернет, спа, массаж, прически.', 'Econom.lv - это отличная возможность найти то, что сердцу угодно за привлекательную цену! В нашем каталоге Вы найдете информацию о  последних скидках  и специальных предложениях в Риге, в удобном стиле и оформлении.', 'Правила пользования и ограничение ответственности', '<h3>Правила пользования и ограничение ответственности</h3>\r\n<p style=''margin-bottom:50px;''>Econom.lv – это информационный ресурс и мы не рекламируем магазины, торговые марки, компании и т.д., если нет на то надлежащих соглашений (относится к разделу Реклама) \r\nМы приложим все усилия для поддержания контента вэб-сайта в обновленном состоянии, но Econom.lv не несет никакой ответственности за скидки или специальные предложения, которые были изменены или недоступны во время показа на сайте. Econom.lv не несет ответственности за любые ошибки или оговорки в контенте, поэтому мы рекомендуем Вам сверять информацию с официальными источниками. Согласно этим правилам пользователь должен понимать, что Econom.lv не предлагает никаких скидок и/или специальных предложений (если нет специального оповещения от администрации сайта), а только информацию о них.</p>\r\n\r\n\r\n<h3>&copy; Закон об авторском праве</h3>\r\n<p style=''margin-bottom:50px;''>Весь контент и дизайн веб-сайта Econom.lv защищен авторскими правами, любое его использование без предварительного соглашения запрещено.</p>\r\n\r\n\r\n<h3>Наша политика конфиденциальности</h3>\r\n<p style=''margin-bottom:50px;''>Куки файлы: некоторые скрипты на нашем сайте могут отсылать куки файлы используемые только в целях статистики нашего сайта.\r\nВся личная информация (имена, адреса, электронные адреса и т.д.), будет использована только в целях Econom.lv и не будет продана и/или обменена и/или передана третьим лицам.</p>\r\n\r\n\r\n<h3>Отзывы посетителей</h3>\r\n<p style=''margin-bottom:50px;''>Econom.lv не несет ответственности за отзывы, мнения и т.п., т.к. эта часть сайта заполняется посетителями, но администрация сайта будет отслеживать и удалять сообщения содержащие спам и ненoрмaтивную лексику.</p>\r\n\r\n\r\n<h3>Соглашение</h3>\r\n<p style=''margin-bottom:50px;''>Econom.lv оставляет за собой право вносить любые изменения в дизайн и контент веб-сайта без какого-либо предупреждения. Используя ссылки и/или баннерные ссылки на этом сайте пользователь может быть перенаправлен на другой веб-сайт, где действуют другие правила, соглашения и т.п., пользователь должен понимать что Econom.lv не несет никакой ответственности за эти вэб-сайты. Использование сайта www.econom.lv подразумевает, что пользователь соглашается со всеми нашими правилами, соглашениями, поправками и т.д.</p>', 'disclaimer'),
(10, 'economlv, econom.lv, скидки, специальные предложения, бренд, салон красоты, гостинница, экстремальный вид спорта, отдых, ночной клуб, дискотека, казино, продукты, магазины, товары, обувь, одежда, мода, электроника, лаптопы, компьютеры, фотографии, ремонт, обустройство, услуги, торговый центр, аксессуары, мобильные телефоны, переводы, кафе, цена, мебель, телевизоры, связь, интернет, спа, массаж, прически.', 'Econom.lv - это отличная возможность найти то, что сердцу угодно за привлекательную цену! В нашем каталоге Вы найдете информацию о  последних скидках  и специальных предложениях в Риге, в удобном стиле и оформлении.', 'Каталог Сфер www.econom.lv', '', 'def_cat');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `sh_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `photo_1` varchar(80) collate utf8_unicode_ci NOT NULL,
  `photo_2` varchar(80) collate utf8_unicode_ci NOT NULL,
  `photo_3` varchar(80) collate utf8_unicode_ci NOT NULL,
  `photo_4` varchar(80) collate utf8_unicode_ci NOT NULL,
  `photo_logo` varchar(80) collate utf8_unicode_ci NOT NULL,
  `photo_1_s` varchar(80) collate utf8_unicode_ci NOT NULL,
  `photo_2_s` varchar(80) collate utf8_unicode_ci NOT NULL,
  `photo_3_s` varchar(80) collate utf8_unicode_ci NOT NULL,
  `photo_4_s` varchar(80) collate utf8_unicode_ci NOT NULL,
  `logo_s` varchar(80) collate utf8_unicode_ci NOT NULL,
  KEY `login` (`login`),
  KEY `sh_name` (`sh_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`login`, `sh_name`, `photo_1`, `photo_2`, `photo_3`, `photo_4`, `photo_logo`, `photo_1_s`, `photo_2_s`, `photo_3_s`, `photo_4_s`, `logo_s`) VALUES
('info@f-lux.lv', 'Fluks', 'img/ltd/Fluks/1.jpeg', 'img/ltd/Fluks/2.jpeg', 'img/ltd/Fluks/3.jpeg', 'img/ltd/Fluks/4.jpeg', 'img/ltd/Fluks/logo.jpeg', 'img/ltd/Fluks/small/1.jpeg', 'img/ltd/Fluks/small/2.jpeg', 'img/ltd/Fluks/small/3.jpeg', 'img/ltd/Fluks/small/4.jpeg', 'img/ltd/Fluks/small/logo_s.jpeg'),
('info@spaschool.lv', 'Spa School', 'img/ltd/Spa School/1.jpeg', 'img/ltd/Spa School/2.jpeg', 'img/ltd/Spa School/3.jpeg', 'img/ltd/Spa School/4.jpeg', 'img/ltd/Spa School/logo.jpeg', 'img/ltd/Spa School/small/1.jpeg', 'img/ltd/Spa School/small/2.jpeg', 'img/ltd/Spa School/small/3.jpeg', 'img/ltd/Spa School/small/4.jpeg', 'img/ltd/Spa School/small/logo_s.jpeg'),
('alexunco@gmail.com', 'Alex and Co', 'img/ltd/SIAAlexandCo/1.jpeg', 'img/ltd/SIAAlexandCo/2.jpeg', 'img/ltd/SIAAlexandCo/3.jpeg', 'img/ltd/SIAAlexandCo/4.jpeg', 'img/ltd/SIAAlexandCo/logo.jpeg', 'img/ltd/SIAAlexandCo/small/1.jpeg', 'img/ltd/SIAAlexandCo/small/2.jpeg', 'img/ltd/SIAAlexandCo/small/3.jpeg', 'img/ltd/SIAAlexandCo/small/4.jpeg', 'img/ltd/SIAAlexandCo/small/logo_s.jpeg'),
('maha21@inbox.lv', 'pohudei.lv', 'img/ltd/pohudei.lv/1.jpeg', 'img/ltd/pohudei.lv/2.jpeg', 'img/ltd/pohudei.lv/3.jpeg', '', 'img/ltd/pohudei.lv/logo.jpeg', 'img/ltd/pohudei.lv/small/1.jpeg', 'img/ltd/pohudei.lv/small/2.jpeg', 'img/ltd/pohudei.lv/small/3.jpeg', '', 'img/ltd/pohudei.lv/small/logo_s.jpeg'),
('info@travelservice.lv', 'Travel Service', 'img/ltd/Travel Service/1.jpeg', 'img/ltd/Travel Service/2.jpeg', 'img/ltd/Travel Service/3.jpeg', 'img/ltd/Travel Service/4.jpeg', 'img/ltd/Travel Service/logo.jpeg', 'img/ltd/Travel Service/small/1.jpeg', 'img/ltd/Travel Service/small/2.jpeg', 'img/ltd/Travel Service/small/3.jpeg', 'img/ltd/Travel Service/small/4.jpeg', 'img/ltd/Travel Service/small/logo_s.jpeg'),
('natalija.brenca@balticom.lv', 'Brench Photography', 'img/ltd/Brench Photography/1.jpeg', 'img/ltd/Brench Photography/2.jpeg', 'img/ltd/Brench Photography/3.jpeg', 'img/ltd/Brench Photography/4.jpeg', 'img/ltd/Brench Photography/logo.jpeg', 'img/ltd/Brench Photography/small/1.jpeg', 'img/ltd/Brench Photography/small/2.jpeg', 'img/ltd/Brench Photography/small/3.jpeg', 'img/ltd/Brench Photography/small/4.jpeg', 'img/ltd/Brench Photography/small/logo_s.jpeg'),
('info@agalmo.lv', 'Agalmo', 'img/ltd/Agalmo/1.jpeg', '', '', '', 'img/ltd/Agalmo/logo.jpeg', 'img/ltd/Agalmo/small/1.jpeg', '', '', '', 'img/ltd/Agalmo/small/logo_s.jpeg'),
('info@nightangel.lv', 'Night-Angel', 'img/ltd/Night-Angel/1.jpeg', 'img/ltd/Night-Angel/2.jpeg', 'img/ltd/Night-Angel/3.jpeg', 'img/ltd/Night-Angel/4.jpeg', 'img/ltd/Night-Angel/logo.jpeg', 'img/ltd/Night-Angel/small/1.jpeg', 'img/ltd/Night-Angel/small/2.jpeg', 'img/ltd/Night-Angel/small/3.jpeg', 'img/ltd/Night-Angel/small/4.jpeg', 'img/ltd/Night-Angel/small/logo_s.jpeg'),
('meriden1@inbox.lv', 'Somashop', 'img/ltd/Somashop/1.jpeg', '', '', '', '', 'img/ltd/Somashop/small/1.jpeg', '', '', '', ''),
('bmw6666@inbox.lv', 'jbrasari', 'img/ltd/jbrasari/1.jpeg', '', '', '', '', 'img/ltd/jbrasari/small/1.jpeg', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login_err_count`
--

CREATE TABLE IF NOT EXISTS `login_err_count` (
  `ip` varchar(15) collate utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `col` tinyint(1) NOT NULL,
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  KEY `login` (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `login_err_count`
--

INSERT INTO `login_err_count` (`ip`, `date`, `col`, `login`) VALUES
('212.129.74.227', '2011-04-14 19:39:43', 1, 'YaykoZajko@inbox.ua.au');

-- --------------------------------------------------------

--
-- Table structure for table `ltd_page_lat`
--

CREATE TABLE IF NOT EXISTS `ltd_page_lat` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `pvn` varchar(15) collate utf8_unicode_ci NOT NULL,
  `sh_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `meta_k` text collate utf8_unicode_ci NOT NULL,
  `meta_d` text collate utf8_unicode_ci NOT NULL,
  `title` varchar(40) collate utf8_unicode_ci NOT NULL,
  `descr` text collate utf8_unicode_ci NOT NULL,
  `web` varchar(40) collate utf8_unicode_ci NOT NULL,
  `phone` varchar(14) collate utf8_unicode_ci NOT NULL,
  `phone_2` varchar(14) collate utf8_unicode_ci NOT NULL,
  `fax` varchar(14) collate utf8_unicode_ci NOT NULL,
  `address` varchar(60) collate utf8_unicode_ci NOT NULL,
  `city` varchar(25) collate utf8_unicode_ci NOT NULL,
  `post` varchar(9) collate utf8_unicode_ci NOT NULL,
  `descr_offer` text collate utf8_unicode_ci NOT NULL,
  `from_date_offer` varchar(15) collate utf8_unicode_ci NOT NULL,
  `till_date_offer` varchar(15) collate utf8_unicode_ci NOT NULL,
  `map` text collate utf8_unicode_ci NOT NULL,
  `b_def` varchar(45) collate utf8_unicode_ci NOT NULL,
  `defcat` varchar(45) collate utf8_unicode_ci NOT NULL,
  `activation` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `login` (`login`),
  KEY `sh_name` (`sh_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `ltd_page_lat`
--

INSERT INTO `ltd_page_lat` (`id`, `login`, `pvn`, `sh_name`, `meta_k`, `meta_d`, `title`, `descr`, `web`, `phone`, `phone_2`, `fax`, `address`, `city`, `post`, `descr_offer`, `from_date_offer`, `till_date_offer`, `map`, `b_def`, `defcat`, `activation`) VALUES
(1, 'info@f-lux.lv', '40103330311', 'Fluks', 'Rīga, Internetveikali, Bižutērija, Fluks, Fashionable Luxury, fashionable, kristāli, rotājumu, luxury, sudrabotās, turīgs, viegls, celms, metāls,  swovski, orģināli', 'Fashionable Luxury piedāvā sieviešu un vīriešu bižutērijas plašu izvēli kvalitātes un skaistuma cienītājiem.', 'Fluks', 'Fashionable Luxury piedāvā sieviešu un vīriešu bižutērijas plašu izvēli kvalitātes un skaistuma cienītājiem. Mēs piedāvājam vairāk kā 1000 atšķirīgus rotājumus, kuri piestāvēs tieši Jums, uzsvērs Jūsu pašpārliecinātības sajūtu, orģinalitāti un stilu. Bižutērija, kuru Jūs šeit redzēsiet – tā ir vienmēr aktuālā dāvana un stilīgs papildinājums apģērbam!<br /><br />\r\n  Fashionable Luxury rotājumu vairākumā tiek izmantoti orģināli Swarovski kristāli, bet tāpat īpaši kristāli no Austrijas.<br /><br />\r\n  Kā rotājumu celms tiek izmantots izturīgs un viegls metāls (ar 18K sudrabotās vai zelta krāsas pieputināšanu). Visa produkcija ir izpildīta augstā kvalitātē!', 'f-lux.lv', '22123421', '22123426', '', 'Čiekurkalna 6.šķērslīnija 7a', 'Rīga', '1026', 'Dažadas preces ar atlaidem līdz 40%. Akcijas preces visu laiku palielinas.', '1 / 1 / 2011', '1 / 1 / 2012', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=%C4%8Ciekurkalna+6.%C5%A1%C4%B7%C4%93rsl%C4%ABnija+7a,+R%C4%ABga,+Latvija&amp;ie=UTF8&amp;hq=&amp;hnear=7+%C4%8Ciekurkalna+6.%C5%A1%C4%B7%C4%93rsl%C4%ABnija,+R%C4%ABga+1026,+Latvija&amp;ll=56.984583,24.175372&amp;spn=0.008114,0.018239&amp;z=15&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=%C4%8Ciekurkalna+6.%C5%A1%C4%B7%C4%93rsl%C4%ABnija+7a,+R%C4%ABga,+Latvija&amp;ie=UTF8&amp;hq=&amp;hnear=7+%C4%8Ciekurkalna+6.%C5%A1%C4%B7%C4%93rsl%C4%ABnija,+R%C4%ABga+1026,+Latvija&amp;ll=56.984583,24.175372&amp;spn=0.008114,0.018239&amp;z=15" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Internetveikali', 'Bižutērija', '1'),
(2, 'info@spaschool.lv', '40103202209', 'Spa School', '', '', 'Spa School', 'SPA SCHOOL - MASĀŽAS UN KOSMETOLOĢIJAS SKOLA<br />\r\n<br />\r\nAKREDITĒTS PROFESIONĀLAIS<br />\r\nMĀCĪBU CENTRS SPA SCHOOL<br />\r\nIzglītības un zinātnes ministrijas licence LR № 3360800565<br />\r\nAkreditācijas Nr. AI 4254<br />\r\n<br />\r\nMācību centram SPA SCHOOL, kas atrodas Rīgas centrā, Kalpaka bulvārī 10 ir profesionālā mācību centra statuss, kuru ir piešķīrusi Latvijas Izglītības Ministrija (licences nr. 3360800565),piešķirta Izglītības un Zinātnes ministrijas akredetācija (akreditācijas Nr. AI4254), SPA SCHOOL ir arī vienīgais mācību centrs Baltijas valstīs, kuram ir piešķirta Starptautiskās ITEC koledžas (Londona) akreditācija.  <br />\r\n<br />\r\nMācību centrs SPA SCHOOL tika dibināts ar Latvijas SPA &amp; Wellness Federācijas atbalstu un pašalaik ir federācijas stratēģiskais partneris.<br />\r\nSpeciālistu apmācība SPA SCHOOL notiek atbilstoši 2008. gada 31. jūlijā pieņemtajam Latvijas Valsts Standartam LVS 450 «Spa operatori un pakalpojumi. Vispārīgas prasības”, kas definē arī SPA speciālista kvalifikāciju. Latvijas SPA Standarts tika izstrādāts, pamatojoties uz Eiropas pieredzi šādu pakalpojumu standartizācijas jautājumos un sadarbojoties ar ekspertiem no Latvijas SPA &amp; Wellness federācijas.<br />\r\nŅemot vērā pedagoģiskā sastāva līmeni, materiāli- tehniskā aprīkojuma un mācību programmu satura līmeni.', 'spaschool.lv', '67244455', '27017160', '', 'Kalpaka bulvāris 10, 3.stāvs', 'Rīga', '1010', 'Noslēdzot līgumu līdz šī gada 31.janvārim, mācību maksa mēnesī tikai 119,-Ls!<br /><br /><br />\r\n\r\nPROFESIONĀLĀ IZGLĪTĪBA<br />\r\n<br />\r\nIegūsti aktuālu PROFESIJU un strādā VISĀ PASAULĒ!<br />\r\n<br />\r\n<br />\r\nPROFESIONĀLAIS KURSS<br />\r\n„Komplementārās un alternatīvās terāpijas SPA-Estētists”<br />\r\n<br />\r\nMācību ilgums:  no 2011.gada 1.marta līdz 2011.gada 24.decembrim<br />\r\nMācības notiek:      8 stundas nedēļā<br />\r\n<br />\r\nSestdienas grupa: no 10:00 līdz 18:00  ( LV)<br />\r\nSvētdienas grupa:  no 10.00 līdz 18.00 (RU)<br />\r\nKursa maksa:       135,- Ls/ mēnesī (iekļaujot PVN 21%)<br />\r\nMācību valoda:    latviešu (LV) / krievu (RU)<br />\r\n<br />\r\n<br />\r\nPēc apmācībām tiek izdoti<br />\r\nDIVI dokumenti par PROFESIONĀLO IZGLĪTĪBU:<br />\r\n1. Latvijas profesionālās pilnveides izglītības apliecība (licences № P1835 akreditācijas №. AI4254).<br />\r\n<br />\r\n2. Starptautiskās koledžas ITEC (London) sertifikāts (UK Accreditation: QCA 500/3250/1 Level 2), kas atbilst Starptautiskajiem standartiem un dod tiesības strādāt 35 pasaules valstīs.<br />\r\nStarptautiskais ITEC sertifikāts atbilst starptautiskajiem standartiem un dod tiesības strādāt SPA, Wellness un skaistuma industrijā (viesnīcās, salonos, kūrortos), vairāk nekā 35 pasaules valstīs, ieskaitot Lielbritāniju, Īriju, ASV, Eiropas savienības valstis, Austrāliju, Āzijas valstis. (www.itecworld.co.uk)<br />\r\n<br />\r\nKURSA PRIEKŠMETI:<br />\r\n• Ievads anatomijā un fizioloģijā;<br />\r\n• Higiēna;<br />\r\n• Pirmās palīdzības kurss;<br />\r\n• Kontrindikācijas SPA procedūru veikšanai;<br />\r\n• Ievads uztura mācībā<br />\r\n• Klasiskā masāža ķermenim<br />\r\n• Aroma masāža;<br />\r\n• Reflektoro zonu terapija;<br />\r\n• Anticelulīta masāža;<br />\r\n• Fitness masāža<br />\r\n• Griķu masāža<br />\r\n• Ekspress masāža SPA TIME OUT<br />\r\n• SPA- filozofija un koncepcija komplementārās un alternatīvās terapijas kursam<br />\r\n• Profesionālā ētika un uzvedības normas;<br />\r\n• Komercdarbības pamati;<br />\r\n• Iepazīšanās ar vadošajām  kosmētiskajām līnijām;<br />\r\n• Iepazīšanās ar  aparātu tehnoloģijām.', '1 / 1 / 2011', '31 / 1 / 2011', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=Kalpaka+bulv%C4%81ris+10,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=40.732051,83.320312&amp;ie=UTF8&amp;hq=&amp;hnear=10+Kalpaka+bulv%C4%81ris,+R%C4%ABga+1050,+Latvija&amp;ll=56.954032,24.108853&amp;spn=0.008121,0.018239&amp;z=15&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=Kalpaka+bulv%C4%81ris+10,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=40.732051,83.320312&amp;ie=UTF8&amp;hq=&amp;hnear=10+Kalpaka+bulv%C4%81ris,+R%C4%ABga+1050,+Latvija&amp;ll=56.954032,24.108853&amp;spn=0.008121,0.018239&amp;z=15" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Izglītība', 'Mācību iestādes', '0'),
(3, 'alexunco@gmail.com', 'LV40103235252', 'Alex and Co', '', '', 'Alex and Co', 'Mēs piedāvājam:<br />\r\nMateriāli<br />\r\n- Nagu pieaudzēšanai<br />\r\n- Skropstu pieaudzēšanai<br />\r\n- Matu pieaudzēšanai<br />\r\n- Vaksācijai<br />\r\nInstrumenti frizieriem<br />\r\nDekoratīva kosmetika', 'fashion-nails.lv', '26843046', '', '', '', 'Jūrmala', '', 'Iepirkties mūsu internet veikalā  <br />\r\nĒrti<br />\r\nIzdevīgi<br />\r\nDāvanas katrā pasūtījumā<br />\r\nPiegāde pa visu Latviju tikai 3 Ls', '2 / 2 / 2011', '2 / 2 / 2012', '', 'Skaistums un veselība', 'Aprīkojums, piederumi', '0'),
(4, 'maha21@inbox.lv', 'LD77789647', 'pohudei.lv', '', '', 'pohudei.lv', 'Хотите быть стройными и хорошо выглядеть? Как Я? Тогда вам сюда!<br />\r\nСамые популярные, а главное эффективные капсулы такие как лида, мезитанг, хергик и многое другое. Поситите мой сайт и выбирите себе подходящие капсулы!', 'pohudei.lv', '26098533', '', '', '', 'Rīga', '', 'Хотите быть стройными и хорошо выглядеть? Как Я? Тогда вам сюда!<br />\r\nСамые популярные, а главное эффективные капсулы такие как лида, мезитанг, хергик и многое другое. Поситите мой сайт и выбирите себе подходящие капсулы!', '3 / 2 / 2011', '24 / 2 / 2011', '', 'Skaistums un veselība', 'Citi', '0'),
(5, 'info@travelservice.lv', '40103274160', 'Travel Service', 'Rīga, Tūrisms, Tūrisma aģentūra, Travel Service, gada, akcija, grieķija, krēta, bulgāri, jaburgasavna, iepriekšpārdošanas, sezonai, vasas, akcijas, turcija, antālija, teikumi, februārim', 'Tūristu pakalpojumu visas ainas, Ceļojumi jebkādā pasaules punktā, Аviobiļetes, Vīzas, Viesnīcas rezervešana, Autobusu tūres, Siltas zemes, Čarteru tūres.', 'Travel Service', 'Tūristu pakalpojumu visas ainas, Ceļojumi jebkādā pasaules punktā, Аviobiļetes, Vīzas, Viesnīcas rezervešana, Autobusu tūres, Siltas zemes, Čarteru tūres.Speciālspiedāvājumi', 'travelservice.lv', '67240045', '29803455', '67240045', 'Ģertrūdes iela 62', 'Rīga', '1011', 'PĒRC AGRĀK – MAKSĀ MAZĀK!<br />\r\nIepriekšpārdošanas akcija 2011.gada vasaras sezonai<br />\r\n<br />\r\nTURCIJA/ANTĀLIJA līdz 35%*<br />\r\nGRIEĶIJA/KRĒTA līdz 30%*<br />\r\nBULGĀRIJA/BURGASA/VARNA līdz 35%*<br />\r\n<br />\r\nIEPRIEKŠPĀRDOŠANAS AKCIJAS NOTEIKUMI <br />\r\n(Akcija spēkā no 17.01.2011 līdz 28.02.2011)<br />\r\n<br />\r\n<br />\r\nRezervējot un apmaksājot ceļojuma braucienu līdz 2011.gada 28.februārim pakalpojumam tiek piešķirta atlaide līdz 30%*.', '4 / 2 / 2011', '28 / 2 / 2011', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=%C4%A2ertr%C5%ABdes+iela+62,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=41.903538,107.138672&amp;ie=UTF8&amp;hq=&amp;hnear=62+%C4%A2ertr%C5%ABdes+iela,+R%C4%ABga+1011,+Latvija&amp;ll=56.951668,24.133444&amp;spn=0.008121,0.018239&amp;z=15&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=%C4%A2ertr%C5%ABdes+iela+62,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=41.903538,107.138672&amp;ie=UTF8&amp;hq=&amp;hnear=62+%C4%A2ertr%C5%ABdes+iela,+R%C4%ABga+1011,+Latvija&amp;ll=56.951668,24.133444&amp;spn=0.008121,0.018239&amp;z=15" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Tūrisms', 'Tūrisma aģentūra', ''),
(6, 'natalija.brenca@balticom.lv', 'LV1063', 'Brench Photography', '', '', 'Brench Photography', 'Хотите, чтобы незабываемые моменты вашей свадьбы не стерлись из памяти, а остались с вами навсегда?<br />\r\n<br />\r\nСделаeм качественные, яркие и живые фотографии, которые станут прекрасной памятью.<br />\r\n<br />\r\nПредлагаем вам двух фотографов за одну цену. Тандем двух фотографов даёт вам гарантию качества и оригинальности.', '2bfoto.lv', '26326461', '', '', 'Maskavas 250', 'Rīga', '1063', 'Помощь в планировании свадьбы, съёмка, обработка фотографий, слайд-шоу. Передам все настроение и красоту самого важного дня в вашей жизни.<br />\r\nСвадебный фотограф - 200 лс/день', '14 / 2 / 2011', '1 / 10 / 2011', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=Maskavas+250,+%D0%A0%D0%B8%D0%B3%D0%B0,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=41.903538,107.138672&amp;ie=UTF8&amp;hq=&amp;hnear=250+Maskavas+iela,+R%C4%ABga+1063,+Latvija&amp;ll=56.916406,24.174128&amp;spn=0.008129,0.018239&amp;z=15&amp;iwloc=A&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=Maskavas+250,+%D0%A0%D0%B8%D0%B3%D0%B0,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=41.903538,107.138672&amp;ie=UTF8&amp;hq=&amp;hnear=250+Maskavas+iela,+R%C4%ABga+1063,+Latvija&amp;ll=56.916406,24.174128&amp;spn=0.008129,0.018239&amp;z=15&amp;iwloc=A" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Kāzām', 'Foto, video pakalpojumi', '0'),
(7, 'info@agalmo.lv', '40103318056', 'Agalmo', 'Rīga, Citi, Tulkojumi, Agalmo, oriģinālu, valodu, iiešana, cenu, liecinā, kurjers, krievu, latviešu, tulkojumu', 'AGALMO Zvērinātu tulku centrs piedāvā tulkojumu notariālu apliecinājumu', 'Agalmo', '', 'agalmo.lv', '28389329', '', '', '', 'Rīga', '', 'AGALMO Zvērinātu tulku centrs piedāvā tulkojumu notariālu apliecinājumu sākot tikai no 16,- Ls *<br />\r\n<br />\r\nJums pašiem nebūs nekur jābrauc, lai iesniegtu oriģinālu!<br />\r\nNosūtiet mums ieskenētu dokumentu, lai mēs varētu to izvērtēt un piedāvāt Jums cenu. Pēc iztulkošanas, mūsu kurjers atbrauks pie Jums uz Rīgu vai Jūrmalu, lai saņemtu dokumenta oriģinālu. Aptuveni pēc stundas mūsu kurjers atvedīs Jums atpakaļ notariāli apliecinātu tulkojumu ar oriģinālu.<br />\r\nTas arī viss - tik vienkārši...<br />\r\n<br />\r\n* Cenā ir iekļauts: vienas lappuses rakstisks tulkojums no krievu / latviešu uz latviešu / krievu valodu, izdrukāšana, iesiešana (ar oriģinālu), zvērināta tulka apstiprinājums, notāra apliecinājums, piegāde.<br />\r\n<br />\r\nNotariāls apliecinājums ir iespējams daudzu valodu tulkojumiem. Iesiešana ir iespējama gan pie oriģināla, gan pie apliecinātas kopijas.<br />\r\nLai uzzinātu precīzu cenu, rakstiet uz e-pastu.<br />\r\nSīkāka informācija par notariāliem apliecinājumiem mūsu mājas lapā.', '10 / 2 / 2011', '28 / 2 / 2011', '', 'Citi', 'Tulkojumi', ''),
(8, 'info@nightangel.lv', '40002158458', 'Night-Angel', 'Rīga, Apģērbs, Apakšveļa, IKResin2, akcijas, naktsveļa, prec, laiku, ejamas, kuras, mainās, līdz, mēni, katru, visu, labākā, seksīgi, akšveļa, seksīga', 'Pievilcīga sieviešu naktsveļa, seksīga apakšveļa, seksīgi halāti, babydoll, naktsveļa jebkurai gaumei,labākā dāvana', 'Night-Angel', 'Pievilcīga sieviešu naktsveļa, seksīga apakšveļa, seksīgi halāti, babydoll, naktsveļa jebkurai gaumei,labākā dāvana', 'Night-Angel.lv', '27715788', '', '', 'Bauskas 20', 'Rīga', '', 'Visu laiku ir pieejamas akcijas preces, kuras mainās katru mēnesi. Akcijas līdz 30%.', '28 / 3 / 2011', '1 / 3 / 2012', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=Bauskas+20,+R%C4%ABga&amp;aq=&amp;sll=56.897379,24.200134&amp;sspn=0.113251,0.41851&amp;ie=UTF8&amp;hq=&amp;hnear=20+Bauskas+iela,+R%C4%ABga+1004,+Latvija&amp;ll=56.921559,24.096322&amp;spn=0.008198,0.018239&amp;z=15&amp;iwloc=A&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=Bauskas+20,+R%C4%ABga&amp;aq=&amp;sll=56.897379,24.200134&amp;sspn=0.113251,0.41851&amp;ie=UTF8&amp;hq=&amp;hnear=20+Bauskas+iela,+R%C4%ABga+1004,+Latvija&amp;ll=56.921559,24.096322&amp;spn=0.008198,0.018239&amp;z=15&amp;iwloc=A" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Apģērbs', 'Apakšveļa', '1'),
(9, 'meriden1@inbox.lv', '50003157131', 'Somashop', 'Рига, Интернет магазин, Одежда, somashop, сумок, производителей, поставки, Прямые, аксессуаров, КАЖДОМУ, ПОКУПАТЕЛЮ, ЛАТ, КАРТА, ПОДАРОЧНАЯ, чемоданов, дорожных, Итальянских, коллекция, Новая', '', 'Somashop', 'www.somashop.lv<br />\r\nНовая коллекция Итальянских сумок. Большой ассортимент женских сумок,кошельков,ремней,дорожных сумок,чемоданов и аксессуаров, Прямые поставки от производителей.', 'somashop.lv', '67260766', '26329741', '67260766', 'Jaņa Asara 14', 'Rīga', '1089', 'КАЖДОМУ ПОКУПАТЕЛЮ ПОДАРОЧНАЯ КАРТА НА 5 ЛАТ', '1 / 4 / 2011', '1 / 6 / 2011', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=Ja%C5%86a+Asara+14,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=54.005807,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=J%C4%81%C5%86a+Asara+iela+14,+R%C4%ABga,+LV-1009,+Latvija&amp;ll=56.955272,24.150224&amp;spn=0.008191,0.018239&amp;z=15&amp;iwloc=A&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=Ja%C5%86a+Asara+14,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=54.005807,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=J%C4%81%C5%86a+Asara+iela+14,+R%C4%ABga,+LV-1009,+Latvija&amp;ll=56.955272,24.150224&amp;spn=0.008191,0.018239&amp;z=15&amp;iwloc=A" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Internetveikali', 'Apģērbs', '1'),
(10, 'bmw6666@inbox.lv', '26047012267', 'jbrasari', 'Valka un raj, Atpūta un izklaide, Kompjūterspēles un videospēles, jbrasari, dlāra, kurss, sdevīgāk, iegādāti, kamēr, cenas, tūlītēja, ielāde, visākās, datorspēl', '', 'jbrasari', 'Datorspēles, tūlītēja ielāde, viszemākās cenas', 'jbr.ucoz.lv', '26042602', '', '', '', 'Valka un raj', '4706', 'kamēr ASV dolāra kurss zems-izdevīgāk iegādāties tagad', '14 / 4 / 2011', '30 / 4 / 2011', '', 'Atpūta un izklaide', 'Kompjūterspēles un videospēles', '0');

-- --------------------------------------------------------

--
-- Table structure for table `ltd_page_rus`
--

CREATE TABLE IF NOT EXISTS `ltd_page_rus` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `pvn` varchar(15) collate utf8_unicode_ci NOT NULL,
  `sh_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `meta_k` text collate utf8_unicode_ci NOT NULL,
  `meta_d` text collate utf8_unicode_ci NOT NULL,
  `title` varchar(40) collate utf8_unicode_ci NOT NULL,
  `descr` text collate utf8_unicode_ci NOT NULL,
  `web` varchar(40) collate utf8_unicode_ci NOT NULL,
  `phone` varchar(14) collate utf8_unicode_ci NOT NULL,
  `phone_2` varchar(14) collate utf8_unicode_ci NOT NULL,
  `fax` varchar(14) collate utf8_unicode_ci NOT NULL,
  `address` varchar(60) collate utf8_unicode_ci NOT NULL,
  `city` varchar(25) collate utf8_unicode_ci NOT NULL,
  `post` varchar(9) collate utf8_unicode_ci NOT NULL,
  `descr_offer` text collate utf8_unicode_ci NOT NULL,
  `from_date_offer` varchar(15) collate utf8_unicode_ci NOT NULL,
  `till_date_offer` varchar(15) collate utf8_unicode_ci NOT NULL,
  `map` text collate utf8_unicode_ci NOT NULL,
  `b_def` varchar(45) collate utf8_unicode_ci NOT NULL,
  `defcat` varchar(45) collate utf8_unicode_ci NOT NULL,
  `activation` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `login` (`login`),
  KEY `sh_name` (`sh_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `ltd_page_rus`
--

INSERT INTO `ltd_page_rus` (`id`, `login`, `pvn`, `sh_name`, `meta_k`, `meta_d`, `title`, `descr`, `web`, `phone`, `phone_2`, `fax`, `address`, `city`, `post`, `descr_offer`, `from_date_offer`, `till_date_offer`, `map`, `b_def`, `defcat`, `activation`) VALUES
(1, 'info@f-lux.lv', '40103330311', 'Fluks', 'Рига, Интернет магазин, Бижутерия, Fluks, Fashionable Luxury, украшений, качестве, fashionable, кристаллы, luxury, прочный, легкий, металл, используется, серебрян', 'Fashionable Luxury предлагает широчайший выбор женской и мужской бижутерии для ценителей качества и красоты.', 'Fluks', 'Fashionable Luxury предлагает широчайший выбор женской и мужской бижутерии для ценителей качества и красоты. У нас вы найдете более 1000 различных украшений, которые подойдут именно вам, подчеркнут вашу уверенность в себе, оригинальность и стиль. Бижутерия, которую вы здесь увидите - это всегда актуальный подарок и стильное дополнение к одежде! <br /><br />\r\n   В большинстве украшений Fashionable Luxury используются оригинальные кристаллы Swarovski, а так же особые кристаллы из Австрии. <br /><br />\r\n   В качестве основы украшений используется прочный и легкий металл (с напылением 18К серебряного или золотого цвета). Вся продукция выполнена в высоком качестве!', 'f-lux.lv', '22123421', '22123426', '', 'Čiekurkalna 6.šķērslīnija 7a', 'Рига', '1026', 'Различные товары со скидками до 40%. Ассортимент акционных товаров постоянно меняется и пополняется.', '1 / 1 / 2011', '1 / 1 / 2012', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=%C4%8Ciekurkalna+6.%C5%A1%C4%B7%C4%93rsl%C4%ABnija+7a,+R%C4%ABga,+Latvija&amp;ie=UTF8&amp;hq=&amp;hnear=7+%C4%8Ciekurkalna+6.%C5%A1%C4%B7%C4%93rsl%C4%ABnija,+R%C4%ABga+1026,+Latvija&amp;ll=56.984583,24.175372&amp;spn=0.008114,0.018239&amp;z=15&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=%C4%8Ciekurkalna+6.%C5%A1%C4%B7%C4%93rsl%C4%ABnija+7a,+R%C4%ABga,+Latvija&amp;ie=UTF8&amp;hq=&amp;hnear=7+%C4%8Ciekurkalna+6.%C5%A1%C4%B7%C4%93rsl%C4%ABnija,+R%C4%ABga+1026,+Latvija&amp;ll=56.984583,24.175372&amp;spn=0.008114,0.018239&amp;z=15" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Интернет магазин', 'Бижутерия', '1'),
(2, 'info@spaschool.lv', '40103202209', 'Spa School', '', '', 'Spa School', 'SPA SCHOOL - ШКОЛА МАССАЖА И КОСМЕТОЛОГИИ<br />\r\n<br />\r\nАККРЕДИТОВАННЫЙ ПРОФЕССИОНАЛЬНЫЙ<br />\r\n УЧЕБНЫЙ ЦЕНТР SPA SCHOOL<br />\r\nМинистерство образования и науки ЛР № 3360800565<br />\r\nАккредитация Nr. AI 4254<br />\r\n<br />\r\nУчебный центр SPA SCHOOL находится в центре Риги, по адресу: бульвар Калпака 10 и имеет статус  профессионального учебного центра (лицензия № 3360800565), присвоена аккредитиция Министерства Науки и Образования Латвийской Республики (Аккредитация Nr.AI 4254), а так же, является единственным центром в странах Балтии, имеющим статус аккредитованного Международного Колледжа ITEC (Лондон).<br />\r\nPA SCHOOL по уровню преподавательского состава, материально-технического оснащения и содержанию учебных программ, является лучшим профессиональным учебным центром в Латвии, готовящим специалистов массажа в индустрии красоты и Spa-отрасли, в соответствии с лицензированными учебными программами.', 'spaschool.lv', '67244455', '27017160', '', 'Kalpaka bulvāris 10, 3.stāvs', 'Рига', '1010', 'Заключая договор на обучение до 31 января, стоимость обучения 119,- Ls/месяц!<br /><br /><br />\r\nПРОФЕССИОНАЛЬНОЕ ОБРАЗОВАНИЕ<br />\r\n<br />\r\nПолучи актуальную ПРОФЕССИЮ и работай по ВСЕМУ МИРУ!<br />\r\n<br />\r\n ПРОФЕССИОНАЛЬНЫЙ КУРС:<br />\r\n„SPA-Эстетика Комплиментарной и Альтернативной Терапии”<br />\r\nновый набор - март 2011 года<br />\r\n<br />\r\nСрок обучения:     с 1 марта 2011 г. по 24 декабря 2011 г.<br />\r\nЗанятия проходят:  8 часов в неделю<br />\r\nCуббота: с 10:00 до 18:00  ( LV)<br />\r\nВоскресенье:  с 10.00 до 18.00 (RU)<br />\r\nСтоимость курса:     135,- Ls/ в месяц (включая PVN 21%)<br />\r\nЯзык обучения:        латышский (LV) / русский (RU)<br />\r\n<br />\r\n<br />\r\nПо окончании обучения выдаются<br />\r\nДВА документа о ПРОФЕССИОНАЛЬНОМ ОБРАЗОВАНИИ:<br />\r\n<br />\r\n1. Сертификат Латвийского образца, свидетельствующий о профессиональном образовании в Латвии (лицензия № P1835, аккредитация  № AI4254).<br />\r\n<br />\r\n2. Международный Сертификат Колледжа ITEC (London), свидетельствующий о профессиональном образовании в 35 странах мира (UK Accreditation: QCA 500/3250/1 Level 2),<br />\r\nМеждународный сертификат колледжа ITEC соответствует международным стандартам и дает право на работу в индустрии SPA, Wellness  и красоты (отелях, салонах, курортах) более чем в 35 странах мира, включая Великобританию, Ирландию, США, страны Европейского Союза, Австралию, странах Азии. (www.itecworld.co.uk)<br />\r\n<br />\r\nПРЕДМЕТЫ КУРСА:<br />\r\n<br />\r\n• Введение в анатомию и физиологию;<br />\r\n• Гигиена;<br />\r\n• Противопоказания к проведению SPA-процедур;<br />\r\n• Оказание первой помощи;<br />\r\n• Введение в диетологию;<br />\r\n• Классический массаж тела;<br />\r\n• Аромамассаж;<br />\r\n• Терапия рефлекторных зон;<br />\r\n• Антицеллюлитный массаж,<br />\r\n• Лимфодренажный массаж,<br />\r\n• Спортивный массаж,<br />\r\n• Массаж горячими мешочками,<br />\r\n• Экспресс-массаж  SPA Time Out.<br />\r\n• SPA-философия и концепция комплиментарной и альтернативной терапии;<br />\r\n• Профессиональная этика и нормы поведения;<br />\r\n• Основы бизнеса и коммерческой деятельности;<br />\r\n• Ознакомление с ведущими косметическими линиями;<br />\r\n• Ознакомление с аппаратными технологиями.', '1 / 1 / 2011', '31 / 1 / 2011', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=Kalpaka+bulv%C4%81ris+10,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=40.732051,83.320312&amp;ie=UTF8&amp;hq=&amp;hnear=10+Kalpaka+bulv%C4%81ris,+R%C4%ABga+1050,+Latvija&amp;ll=56.954032,24.108853&amp;spn=0.008121,0.018239&amp;z=15&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=Kalpaka+bulv%C4%81ris+10,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=40.732051,83.320312&amp;ie=UTF8&amp;hq=&amp;hnear=10+Kalpaka+bulv%C4%81ris,+R%C4%ABga+1050,+Latvija&amp;ll=56.954032,24.108853&amp;spn=0.008121,0.018239&amp;z=15" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Образовaние', 'Учебые заведния', '0'),
(3, 'alexunco@gmail.com', 'LV40103235252', 'Alex and Co', '', '', 'Alex and Co', 'Мы предлагаем :<br />\r\nМатериалы<br />\r\n- Для наращивания ногтей<br />\r\n- Для наращивания ресниц<br />\r\n- Для наращивания волос<br />\r\n- Для ваксации<br />\r\nИнструменты для парикмахеров<br />\r\nДекоративная косметика', 'fashion-nails.lv', '26843046', '', '', '', 'Юрмала', '', 'Делать покупки в нашем магазине<br />\r\nУдобно<br />\r\nВыгодно<br />\r\nПодарки в каждой посылке<br />\r\nДоставка по всей Латвии только 3 Ls', '2 / 2 / 2011', '2 / 2 / 2012', '', 'Красота и здоровье', 'Оборудование, приборы', '0'),
(4, 'maha21@inbox.lv', 'LD77789647', 'pohudei.lv', '', '', 'pohudei.lv', 'Хотите быть стройными и хорошо выглядеть? Как Я? Тогда вам сюда!<br />\r\nСамые популярные, а главное эффективные капсулы такие как лида, мезитанг, хергик и многое другое. Поситите мой сайт и выбирите себе подходящие капсулы!', 'pohudei.lv', '26098533', '', '', '', 'Рига', '', 'Хотите быть стройными и хорошо выглядеть? Как Я? Тогда вам сюда!<br />\r\nСамые популярные, а главное эффективные капсулы такие как лида, мезитанг, хергик и многое другое. Поситите мой сайт и выбирите себе подходящие капсулы!', '3 / 2 / 2011', '24 / 2 / 2011', '', 'Красота и здоровье', 'Другое', '0'),
(5, 'info@travelservice.lv', '40103274160', 'Travel Service', 'Рига, Туризм, Туристическое агенство, Travel Service, сегодня, лето, начинается, гарантия, лучшей, цены, всегда, хорватия, болгария, направления, тур', 'Все виды туристических услуг,Путешествия в любую точку мира,Авиaбилеты,Визы,Бронирование отелей,Автобусные туры,Теплые страны,Чартерные т', 'Travel Service', 'Все виды туристических услуг,Путешествия в любую точку мира,Авиaбилеты,Визы,Бронирование отелей,Автобусные туры,Теплые страны,Чартерные туры.Спецпредложения!', 'travelservice.lv', '67240045', '29803455', '67240045', 'Ģertrūdes iela 62', 'Рига', '1011', 'Скидки до 35% Лето начинается сегодня!!!<br />\r\nЛето начинается сегодня!!! <br />\r\n<br />\r\nСкдки до 35% на все летние направления !!!<br />\r\n<br />\r\n<br />\r\nТурция - от 233.00<br />\r\n<br />\r\nГреция - от 199.00<br />\r\n<br />\r\nБолгария -от 199.00<br />\r\n<br />\r\nХорватия - от 303.00<br />\r\n<br />\r\nГарантия лучшей цены !<br />\r\n<br />\r\n<br />\r\nВсегда имеются спецпредложения!<br />\r\n<br />\r\nВозможность бронировать on-line<br />\r\n<br />\r\nwww.travelservice.lv<br />\r\n<br />\r\nДополнительную информацию<br />\r\n<br />\r\nМожно получить по тел: 29803455', '4 / 2 / 2011', '28 / 2 / 2011', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=%C4%A2ertr%C5%ABdes+iela+62,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=41.903538,107.138672&amp;ie=UTF8&amp;hq=&amp;hnear=62+%C4%A2ertr%C5%ABdes+iela,+R%C4%ABga+1011,+Latvija&amp;ll=56.951668,24.133444&amp;spn=0.008121,0.018239&amp;z=15&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=%C4%A2ertr%C5%ABdes+iela+62,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=41.903538,107.138672&amp;ie=UTF8&amp;hq=&amp;hnear=62+%C4%A2ertr%C5%ABdes+iela,+R%C4%ABga+1011,+Latvija&amp;ll=56.951668,24.133444&amp;spn=0.008121,0.018239&amp;z=15" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Туризм', 'Туристическое агенство', '0'),
(6, 'natalija.brenca@balticom.lv', 'LV1063', 'Brench Photography', '', '', 'Brench Photography', 'Хотите, чтобы незабываемые моменты вашей свадьбы не стерлись из памяти, а остались с вами навсегда?<br />\r\n<br />\r\nСделаeм качественные, яркие и живые фотографии, которые станут прекрасной памятью.<br />\r\n<br />\r\nПредлагаем вам двух фотографов за одну цену. Тандем двух фотографов даёт вам гарантию качества и оригинальности.', '2bfoto.lv', '26326461', '', '', 'Maskavas 250', 'Рига', '1063', 'Помощь в планировании свадьбы, съёмка, обработка фотографий, слайд-шоу. Передам все настроение и красоту самого важного дня в вашей жизни.<br />\r\nСвадебный фотограф - 200 лс/день', '14 / 2 / 2011', '1 / 10 / 2011', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=Maskavas+250,+%D0%A0%D0%B8%D0%B3%D0%B0,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=41.903538,107.138672&amp;ie=UTF8&amp;hq=&amp;hnear=250+Maskavas+iela,+R%C4%ABga+1063,+Latvija&amp;ll=56.916406,24.174128&amp;spn=0.008129,0.018239&amp;z=15&amp;iwloc=A&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=Maskavas+250,+%D0%A0%D0%B8%D0%B3%D0%B0,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=41.903538,107.138672&amp;ie=UTF8&amp;hq=&amp;hnear=250+Maskavas+iela,+R%C4%ABga+1063,+Latvija&amp;ll=56.916406,24.174128&amp;spn=0.008129,0.018239&amp;z=15&amp;iwloc=A" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Для свадьбы', 'Фото, Видео услуги', '0'),
(7, 'info@agalmo.lv', '40103318056', 'Agalmo', 'Рига, Другое, Переводы, Agalmo, подробности, епочте, телефону, только, заверением, предложение, перевод, нотариальным', 'Перевод с нотариальным заверением', 'Agalmo', '', 'agalmo.lv', '28389329', '', '', '', 'Рига', '', 'Перевод с нотариальным заверением только 16,- Ls.<br />\r\nПодробности по е-почте и телефону.', '10 / 2 / 2011', '28 / 2 / 2011', '', 'Другое', 'Переводы', '0'),
(8, 'info@nightangel.lv', '40002158458', 'Night-Angel', 'Рига, Одежда, Нижнее белье, IKResin2, каждий, месяцБолше, информации, сайте, меняется, акциями, ночное, белье, Акция, Товар, Женское', 'Женское ночное белье', 'Night-Angel', 'Женское ночное белье.', 'Night-Angel.lv', '27715788', '', '', 'Bauskas 20', 'Рига', '', 'Акция до 30%. Товар с акциями меняется каждий месяц.Болше информации на сайте.', '28 / 3 / 2011', '1 / 3 / 2012', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=Bauskas+20,+R%C4%ABga&amp;aq=&amp;sll=56.897379,24.200134&amp;sspn=0.113251,0.41851&amp;ie=UTF8&amp;hq=&amp;hnear=20+Bauskas+iela,+R%C4%ABga+1004,+Latvija&amp;ll=56.921559,24.096322&amp;spn=0.008198,0.018239&amp;z=15&amp;iwloc=A&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=Bauskas+20,+R%C4%ABga&amp;aq=&amp;sll=56.897379,24.200134&amp;sspn=0.113251,0.41851&amp;ie=UTF8&amp;hq=&amp;hnear=20+Bauskas+iela,+R%C4%ABga+1004,+Latvija&amp;ll=56.921559,24.096322&amp;spn=0.008198,0.018239&amp;z=15&amp;iwloc=A" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Одежда', 'Нижнее белье', '1'),
(10, 'meriden1@inbox.lv', '50003157131', 'Somashop', 'Рига, Интернет магазин, Одежда, somashop, сумок, производителей, поставки, Прямые, аксессуаров, КАЖДОМУ, ПОКУПАТЕЛЮ, ЛАТ, КАРТА, ПОДАРОЧНАЯ, чемоданов, дорожных, Итальянских, коллекция, Новая', '', 'Somashop', 'www.somashop.lv<br />\r\nНовая коллекция Итальянских сумок. Большой ассортимент женских сумок,кошельков,ремней,дорожных сумок,чемоданов и аксессуаров, Прямые поставки от производителей.', 'somashop.lv', '67260766', '26329741', '67260766', 'Jaņa Asara 14', 'Рига', '1089', 'КАЖДОМУ ПОКУПАТЕЛЮ ПОДАРОЧНАЯ КАРТА НА 5 ЛАТ', '1 / 4 / 2011', '1 / 6 / 2011', '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=lv&amp;geocode=&amp;q=Ja%C5%86a+Asara+14,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=54.005807,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=J%C4%81%C5%86a+Asara+iela+14,+R%C4%ABga,+LV-1009,+Latvija&amp;ll=56.955272,24.150224&amp;spn=0.008191,0.018239&amp;z=15&amp;iwloc=A&amp;output=embed"></iframe><br /><small><a href="http://maps.google.com/maps?f=q&amp;source=embed&amp;hl=lv&amp;geocode=&amp;q=Ja%C5%86a+Asara+14,+R%C4%ABga,+Latvija&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=54.005807,135.263672&amp;ie=UTF8&amp;hq=&amp;hnear=J%C4%81%C5%86a+Asara+iela+14,+R%C4%ABga,+LV-1009,+Latvija&amp;ll=56.955272,24.150224&amp;spn=0.008191,0.018239&amp;z=15&amp;iwloc=A" style="color:#0000FF;text-align:left">Skatīt lielāku karti</a></small>', 'Интернет магазин', 'Одежда', '1'),
(11, 'bmw6666@inbox.lv', '26047012267', 'jbrasari', 'Valka un raj, Atpūta un izklaide, Kompjūterspēles un videospēles, jbrasari, dlāra, kurss, sdevīgāk, iegādāti, kamēr, cenas, tūlītēja, ielāde, visākās, datorspēl', '', 'jbrasari', 'Datorspēles, tūlītēja ielāde, viszemākās cenas', 'jbr.ucoz.lv', '26042602', '', '', '', 'Валка и р-он', '4706', 'kamēr ASV dolāra kurss zems-izdevīgāk iegādāties tagad', '14 / 4 / 2011', '30 / 4 / 2011', '', 'Отдых и развлечения', 'Компьютерные и видеоигры', '0');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` smallint(6) NOT NULL auto_increment,
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `for_sh_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `from` varchar(50) collate utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `text` text collate utf8_unicode_ci NOT NULL,
  `active` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `login` (`from`),
  KEY `for_sh_name` (`for_sh_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `login`, `for_sh_name`, `from`, `date`, `text`, `active`) VALUES
(1, 'info@f-lux.lv', '', 'admin@econom.lv', '2011-01-18', 'Благодарим вас за регистрацию вашей фирмы в нашем каталоге. Если у вас появятся любые вопросы или пожелания, вы можете связаться с нами через раздел Контакты. Мы будем рады узнать ваше мнение о работе нашей системы или если вы обнаружите ошибки в работе каталога, системы администрирования, или контексте просим вас сообщить нам об этом. Мы работаем для вас вместе с вами.', '0'),
(4, 'project4444@inbox.lv', '', 'admin@econom.lv', '2011-01-23', 'Благодарим вас за регистрацию вашей фирмы в нашем каталоге. Если у вас появятся любые вопросы или пожелания, вы можете связаться с нами через раздел Контакты. Мы будем рады узнать ваше мнение о работе нашей системы или если вы обнаружите ошибки в работе каталога, системы администрирования, или контексте просим вас сообщить нам об этом. Мы работаем для вас вместе с вами.', '1'),
(5, 'info@spaschool.lv', '', 'admin@econom.lv', '2011-01-24', 'Pateicamies par Jūsu firmas reģistrāciju mūsu katalogā. Ja Jums rodas kādi jautājumi vai vēlmes, sazinieties ar mums caur sadaļu Kontakti. Būsim pateicīgi, ja izteiksiet savu viedokli par mūsu sistēmas darbu vai arī, ja esiet pamanījis kļūdu katalogā, sistēmas administrācijā, vai saturā, lūdzam par to ziņot mums. Mēs strādājam Jums kopā ar Jums.', '1'),
(6, 'alexunco@gmail.com', '', 'admin@econom.lv', '2011-02-02', 'Pateicamies par Jūsu firmas reģistrāciju mūsu katalogā. Ja Jums rodas kādi jautājumi vai vēlmes, sazinieties ar mums caur sadaļu Kontakti. Būsim pateicīgi, ja izteiksiet savu viedokli par mūsu sistēmas darbu vai arī, ja esiet pamanījis kļūdu katalogā, sistēmas administrācijā, vai saturā, lūdzam par to ziņot mums. Mēs strādājam Jums kopā ar Jums.', '1'),
(7, 'alexunco@gmail.com', 'SIA Alex and Co', 'admin@econom.lv', '2011-02-02', 'Добрый день,<br />\r\n<br />\r\nДля полной активации вашей страницы, ваша фирма должна предоставлять акции или скидкидля ваших клиентов. Это обязательное условие каталога скидок.<br />\r\n<br />\r\nС уважением<br />\r\nАдминистрация сайта', '1'),
(9, 'maha21@inbox.lv', '', 'admin@econom.lv', '2011-02-03', 'Благодарим вас за регистрацию вашей фирмы в нашем каталоге. Если у вас появятся любые вопросы или пожелания, вы можете связаться с нами через раздел Контакты. Мы будем рады узнать ваше мнение о работе нашей системы или если вы обнаружите ошибки в работе каталога, системы администрирования, или контексте просим вас сообщить нам об этом. Мы работаем для вас вместе с вами.', '0'),
(10, 'info@spaschool.lv', 'Mācību centrs SPA SCHOOL', 'admin@econom.lv', '2011-02-04', 'Ваша страница была деактивирована, так как время действия представленных вами акций/скидок закончилось.', '0'),
(11, 'maha21@inbox.lv', 'pohudei.lv', 'admin@econom.lv', '2011-02-04', 'Добрый день<br />\r\n<br />\r\nК сожалению мы не смогли найти ваш регистрационный номер в базе регистра, возможно вы сделали ошибку при регистрации. Вы можете его исправить через меню вашей страницы в профиле.<br />\r\n<br />\r\nТак как сайт www.econom.lv является каталогом скидок, вы должны предоставить скидики для ваших клиентов.<br />\r\n<br />\r\nС уважением<br />\r\nАдминистрация сайта', '0'),
(12, 'info@travelservice.lv', '', 'admin@econom.lv', '2011-02-04', 'Благодарим вас за регистрацию вашей фирмы в нашем каталоге. Если у вас появятся любые вопросы или пожелания, вы можете связаться с нами через раздел Контакты. Мы будем рады узнать ваше мнение о работе нашей системы или если вы обнаружите ошибки в работе каталога, системы администрирования, или контексте просим вас сообщить нам об этом. Мы работаем для вас вместе с вами.', '0'),
(15, 'natalija.brenca@balticom.lv', '', 'admin@econom.lv', '2011-02-08', 'Благодарим вас за регистрацию вашей фирмы в нашем каталоге. Если у вас появятся любые вопросы или пожелания, вы можете связаться с нами через раздел Контакты. Мы будем рады узнать ваше мнение о работе нашей системы или если вы обнаружите ошибки в работе каталога, системы администрирования, или контексте просим вас сообщить нам об этом. Мы работаем для вас вместе с вами.', '0'),
(16, 'natalija.brenca@balticom.lv', 'BRENCH PHOTOGRAPHY', 'admin@econom.lv', '2011-02-08', 'Добрый день,<br />\r\n<br />\r\nМы не можем активировать вашу страницу по причине того, что мы не смогли найти ваш регистрационный номер в регистре.<br />\r\n<br />\r\nВы можете изменить его через меню администрирования страницы в профиле, пройдя в раздел Изменить данные.<br />\r\n<br />\r\nС уважением<br />\r\nАдминистрация сайта', '1'),
(17, 'info@agalmo.lv', '', 'admin@econom.lv', '2011-02-10', 'Pateicamies par Jūsu firmas reģistrāciju mūsu katalogā. Ja Jums rodas kādi jautājumi vai vēlmes, sazinieties ar mums caur sadaļu Kontakti. Būsim pateicīgi, ja izteiksiet savu viedokli par mūsu sistēmas darbu vai arī, ja esiet pamanījis kļūdu katalogā, sistēmas administrācijā, vai saturā, lūdzam par to ziņot mums. Mēs strādājam Jums kopā ar Jums.', '1'),
(18, 'info@travelservice.lv', 'Travel Service', 'admin@econom.lv', '2011-02-28', 'Ваша страница была деактивирована, так как время действия представленных вами акций/скидок закончилось.', '0'),
(19, 'info@agalmo.lv', 'Agalmo', 'admin@econom.lv', '2011-02-28', 'Ваша страница была деактивирована, так как время действия представленных вами акций/скидок закончилось.', '0'),
(20, 'info@nightangel.lv', '', 'admin@econom.lv', '2011-03-28', 'Pateicamies par Jūsu firmas reģistrāciju mūsu katalogā. Ja Jums rodas kādi jautājumi vai vēlmes, sazinieties ar mums caur sadaļu Kontakti. Būsim pateicīgi, ja izteiksiet savu viedokli par mūsu sistēmas darbu vai arī, ja esiet pamanījis kļūdu katalogā, sistēmas administrācijā, vai saturā, lūdzam par to ziņot mums. Mēs strādājam Jums kopā ar Jums.', '0'),
(21, 'meriden1@inbox.lv', '', 'admin@econom.lv', '2011-03-31', 'Благодарим вас за регистрацию вашей фирмы в нашем каталоге. Если у вас появятся любые вопросы или пожелания, вы можете связаться с нами через раздел Контакты. Мы будем рады узнать ваше мнение о работе нашей системы или если вы обнаружите ошибки в работе каталога, системы администрирования, или контексте просим вас сообщить нам об этом. Мы работаем для вас вместе с вами.', '0'),
(22, 'bmw6666@inbox.lv', '', 'admin@econom.lv', '2011-04-14', 'Pateicamies par Jūsu firmas reģistrāciju mūsu katalogā. Ja Jums rodas kādi jautājumi vai vēlmes, sazinieties ar mums caur sadaļu Kontakti. Būsim pateicīgi, ja izteiksiet savu viedokli par mūsu sistēmas darbu vai arī, ja esiet pamanījis kļūdu katalogā, sistēmas administrācijā, vai saturā, lūdzam par to ziņot mums. Mēs strādājam Jums kopā ar Jums.', '1'),
(23, 'bmw6666@inbox.lv', 'jbrasari', 'admin@econom.lv', '2011-04-14', 'Добрый день,<br />\r\n<br />\r\nВаша страница не может быть активированна, т.к. мы не смогли найти введенный вами регистрационный номер в регистре.<br />\r\n<br />\r\nС уважением<br />\r\nАдминистрация сайта<br />\r\nwww.econom.lv', '0');

-- --------------------------------------------------------

--
-- Table structure for table `stats`
--

CREATE TABLE IF NOT EXISTS `stats` (
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `sh_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `value` date NOT NULL,
  `views` int(11) NOT NULL,
  KEY `login` (`login`),
  KEY `sh_name` (`sh_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stats`
--

INSERT INTO `stats` (`login`, `sh_name`, `value`, `views`) VALUES
('info@f-lux.lv', 'Fluks', '2011-04-14', 289),
('info@nightangel.lv', 'Night-Angel', '2011-04-14', 43),
('meriden1@inbox.lv', 'Somashop', '2011-04-14', 36);

-- --------------------------------------------------------

--
-- Table structure for table `top_index`
--

CREATE TABLE IF NOT EXISTS `top_index` (
  `sh_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `date_reg` datetime NOT NULL,
  `ip` varchar(15) collate utf8_unicode_ci NOT NULL,
  `votes` int(11) NOT NULL,
  KEY `sh_name` (`sh_name`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `top_index`
--

INSERT INTO `top_index` (`sh_name`, `date_reg`, `ip`, `votes`) VALUES
('Fluks', '2011-03-02 05:55:21', '87.198.114.25', 1),
('Fluks', '2011-03-01 09:24:33', '81.198.226.110', 1),
('Fluks', '2011-03-01 10:19:21', '46.109.209.134', 2),
('FLUKS', '2011-03-19 20:39:28', '66.249.72.146', 14),
('Fluks', '2011-02-28 22:21:13', '87.198.25.127', 1),
('Fluks', '2011-03-02 13:53:51', '85.92.84.232', 1),
('Fluks', '2011-03-02 14:02:05', '87.198.26.92', 1),
('Fluks', '2011-03-19 04:25:48', '65.55.3.135', 4),
('Fluks', '2011-03-04 00:22:03', '87.198.25.186', 1),
('Fluks', '2011-03-04 01:13:56', '88.135.148.246', 1),
('Fluks', '2011-03-04 16:12:03', '85.48.106.69', 1),
('Fluks', '2011-03-04 19:32:10', '87.198.24.198', 1),
('Fluks', '2011-03-30 11:34:40', '66.249.71.149', 5),
('Fluks', '2011-03-05 01:54:23', '87.198.27.53', 1),
('Fluks', '2011-03-26 03:41:30', '66.249.66.169', 16),
('Fluks', '2011-03-06 09:01:27', '86.63.166.59', 1),
('Fluks', '2011-03-06 18:07:46', '85.91.28.50', 1),
('Fluks', '2011-03-07 11:01:06', '87.198.113.193', 1),
('Fluks', '2011-03-07 19:51:53', '87.246.180.137', 1),
('Fluks', '2011-03-07 23:05:46', '77.38.196.139', 1),
('Fluks', '2011-03-08 20:53:32', '195.13.195.72', 1),
('Fluks', '2011-03-09 11:38:37', '79.132.85.108', 1),
('Fluks', '2011-03-09 17:29:25', '46.109.12.133', 1),
('Fluks', '2011-03-10 00:54:07', '46.109.17.145', 1),
('Fluks', '2011-03-24 21:11:33', '67.195.110.190', 2),
('Fluks', '2011-03-15 19:25:56', '82.193.76.204', 1),
('Fluks', '2011-03-16 07:55:18', 'unknown', 1),
('Fluks', '2011-03-16 19:59:56', '95.133.245.137', 1),
('FLUKS', '2011-03-17 00:15:20', '207.46.195.226', 1),
('Fluks', '2011-03-18 17:49:31', '217.69.134.113', 1),
('Fluks', '2011-03-20 07:22:03', '87.198.114.142', 1),
('Fluks', '2011-03-22 08:00:17', '207.182.147.34', 1),
('Fluks', '2011-03-22 15:43:15', '213.21.219.28', 1),
('Fluks', '2011-03-22 22:22:23', '94.30.135.119', 1),
('Fluks', '2011-03-22 23:39:12', '87.198.113.246', 1),
('Fluks', '2011-03-23 18:02:48', '82.193.84.153', 1),
('Fluks', '2011-03-24 16:19:31', '85.234.189.79', 1),
('Fluks', '2011-04-04 06:56:32', '195.122.24.148', 2),
('Fluks', '2011-03-25 12:34:13', '81.198.35.83', 1),
('Fluks', '2011-03-25 16:57:26', '87.198.114.141', 1),
('FLUKS', '2011-03-28 11:24:00', '66.249.72.12', 1),
('Fluks', '2011-03-28 18:23:25', '46.109.160.105', 1),
('Fluks', '2011-03-28 19:47:37', '91.188.62.35', 1),
('Night-Angel', '2011-03-30 09:58:36', '87.198.115.96', 1),
('Night-Angel', '2011-03-30 17:18:16', '87.198.24.57', 1),
('Night-Angel', '2011-03-30 20:08:01', '85.91.28.186', 1),
('Fluks', '2011-03-31 00:12:23', '87.198.114.84', 1),
('Night-Angel', '2011-03-31 00:12:33', '87.198.114.84', 1),
('Fluks', '2011-03-31 11:47:03', '87.198.24.130', 1),
('Night-Angel', '2011-03-31 16:35:48', '66.249.72.245', 2),
('Night-Angel', '2011-04-01 05:18:33', '87.198.115.98', 1),
('Somashop', '2011-04-01 05:28:49', '87.198.115.98', 1),
('Somashop', '2011-04-04 05:09:53', '66.249.72.245', 3),
('FLUKS', '2011-04-02 17:35:59', '207.46.204.196', 1),
('Fluks', '2011-04-02 19:21:54', '77.241.161.98', 1),
('Fluks', '2011-04-14 16:26:13', '66.249.72.245', 11),
('Night-Angel', '2011-04-04 15:54:24', '109.165.20.135', 1),
('Somashop', '2011-04-04 15:58:18', '109.165.20.135', 1),
('Fluks', '2011-04-04 15:58:32', '109.165.20.135', 1),
('Night-Angel', '2011-04-06 08:16:35', '82.193.66.33', 1),
('Fluks', '2011-04-06 08:18:21', '82.193.66.33', 1),
('Night-Angel', '2011-04-07 04:23:56', '85.17.58.128', 1),
('Somashop', '2011-04-07 20:42:49', '130.226.70.177', 1),
('Fluks', '2011-04-07 20:44:19', '130.226.70.177', 1),
('Somashop', '2011-04-07 23:37:55', '67.195.112.106', 1),
('Night-Angel', '2011-04-08 21:23:16', '46.109.164.230', 1),
('Night-Angel', '2011-04-08 21:29:51', '67.195.112.106', 1),
('FLUKS', '2011-04-09 04:14:29', '178.154.163.30', 1),
('Night-Angel', '2011-04-11 10:32:32', '212.93.100.172', 1),
('Fluks', '2011-04-11 19:17:40', '85.91.28.86', 1),
('Night-Angel', '2011-04-11 19:18:36', '85.91.28.86', 1),
('Somashop', '2011-04-12 06:15:57', '87.198.27.219', 1),
('Night-Angel', '2011-04-12 06:16:21', '87.198.27.219', 1),
('Fluks', '2011-04-12 06:16:44', '87.198.27.219', 1),
('Somashop', '2011-04-14 13:22:47', '87.110.216.203', 1),
('Night-Angel', '2011-04-14 19:30:30', '212.129.74.227', 1),
('Somashop', '2011-04-14 19:31:06', '212.129.74.227', 1),
('Fluks', '2011-04-14 19:34:37', '212.129.74.227', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `passwd` varchar(50) collate utf8_unicode_ci NOT NULL,
  `nick` varchar(20) collate utf8_unicode_ci NOT NULL,
  `avatar` varchar(35) collate utf8_unicode_ci NOT NULL,
  `reg_date` datetime NOT NULL,
  `activation` enum('0','1') collate utf8_unicode_ci NOT NULL,
  `last_visit` datetime NOT NULL,
  `flag` enum('0','1','2') collate utf8_unicode_ci NOT NULL default '0',
  KEY `login` (`login`),
  KEY `passwd` (`passwd`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`login`, `passwd`, `nick`, `avatar`, `reg_date`, `activation`, `last_visit`, `flag`) VALUES
('natalija.brenca@balticom.lv', '5bca05fec0e38264ccc6e5f1e2537e8244TrAh0885', 'natkin', 'avatars/new_user/no_avatar.jpg', '2011-01-18 20:00:36', '1', '2011-01-18 20:23:36', '0'),
('kompozicija@inbox.lv', 'b688fef7c025807716eee8c8ce472f3944TrAh0885', 'Sniedze', 'avatars/new_user/no_avatar.jpg', '2011-01-18 20:39:28', '1', '2011-01-18 20:39:28', '0'),
('info@f-lux.lv', '4a54c656c8d8a0822068302f2b8ae1a344TrAh0885', 'fluxury', 'avatars/new_user/no_avatar.jpg', '2011-01-18 22:02:38', '1', '2011-01-18 22:02:38', '0'),
('YaykoZajko@inbox.ua.au', 'd7482bf6737fa194d218347e7da25ae444TrAh0885', 'Prulj!', 'avatars/new_user/no_avatar.jpg', '2011-01-18 22:47:42', '1', '2011-04-14 20:01:00', '2'),
('project4444@inbox.lv', '2a6fce73616d02b5c461156e81ed163e44TrAh0885', 'test', 'avatars/new_user/no_avatar.jpg', '2011-01-23 10:07:34', '1', '2011-03-29 14:29:13', '0'),
('info@spaschool.lv', '9676c5512f00157b5b858544ee93d49f44TrAh0885', 'SPA SCHOOL', 'avatars/new_user/no_avatar.jpg', '2011-01-24 11:06:51', '1', '2011-01-24 15:18:16', '0'),
('sergeiy2@live.ru', 'c2a677d805323f54ca73853a0f048d2444TrAh0885', 'sergeiy2', 'avatars/new_user/no_avatar.jpg', '2011-02-02 05:43:09', '1', '2011-02-02 05:43:09', '0'),
('alexunco@gmail.com', '39d07158964df12dbcc4e67b94c1f80444TrAh0885', 'Alex and Co', 'avatars/new_user/no_avatar.jpg', '2011-02-02 06:41:01', '1', '2011-02-02 06:41:01', '0'),
('wipovnik20082008@rambler.ru', '0ec363f7d144806df342a5704727152f44TrAh0885', 'VIVASAN', 'avatars/new_user/no_avatar.jpg', '2011-02-02 10:13:12', '1', '2011-02-02 10:13:12', '0'),
('psyche@psyche.lv', 'a3003990d6f2b48d69fa004690171d6a44TrAh0885', 'Psyche', 'avatars/new_user/no_avatar.jpg', '2011-02-03 09:28:19', '1', '2011-02-03 09:28:19', '0'),
('maha21@inbox.lv', 'cf27ee321d4ebf46183f5f2f16b649bf44TrAh0885', 'maha21', 'avatars/new_user/no_avatar.jpg', '2011-02-03 20:12:58', '1', '2011-02-03 20:12:58', '0'),
('samopalik@inbox.lv', 'ede98cc349d9205e017598010442df5044TrAh0885', 'samopalik', 'avatars/new_user/no_avatar.jpg', '2011-02-03 22:15:05', '1', '2011-02-03 22:15:05', '0'),
('info@byorange.lv', '38d4de31172387e1f30d18f9051ad09044TrAh0885', 'Denis', 'avatars/new_user/no_avatar.jpg', '2011-02-04 02:47:38', '1', '2011-02-04 03:51:12', '0'),
('info@travelservice.lv', '58f20fa187c8c49b458fe3d16c679cab44TrAh0885', 'Travel Service', 'avatars/1296831843.jpg', '2011-02-04 07:52:11', '1', '2011-02-04 15:05:18', '0'),
('civila@inbox.lv', '834d553945bab523465802634035be7344TrAh0885', 'baroks', 'avatars/new_user/no_avatar.jpg', '2011-02-04 08:02:14', '1', '2011-02-04 08:02:14', '0'),
('zinaidalovcova@inbox.lv', 'f80aaa50095f89a999ef07ec968bd74d44TrAh0885', 'vogel', 'avatars/new_user/no_avatar.jpg', '2011-02-04 18:53:20', '1', '2011-02-04 18:55:01', '0'),
('badabum@inbox.lv', '1649e553bf1d8fa58231606e74fd043044TrAh0885', 'El_Sueno', 'avatars/new_user/no_avatar.jpg', '2011-02-08 11:19:30', '1', '2011-02-08 11:20:55', '0'),
('astratovam@inbox.lv', '183326a7b6dbbf6a1a44d1e7c82fd41644TrAh0885', 'BelijFilin', 'avatars/new_user/no_avatar.jpg', '2011-02-08 16:20:43', '1', '2011-02-08 16:20:43', '0'),
('info@agalmo.lv', '8946626cbf2469b574dff261a00292fd44TrAh0885', 'Agalmo', 'avatars/new_user/no_avatar.jpg', '2011-02-10 11:59:45', '1', '2011-02-10 11:59:45', '0'),
('viva001@inbox.lv', '27385663bb337055625e928e641939b844TrAh0885', 'Viva', 'avatars/new_user/no_avatar.jpg', '2011-02-11 13:49:56', '1', '2011-02-11 13:49:56', '0'),
('alexandrrrra@gmail.com', '7106ebd31aff1eb7e5fb5fb09c3278c444TrAh0885', 'AleXandra', 'avatars/new_user/no_avatar.jpg', '2011-02-11 20:03:04', '1', '2011-02-11 20:03:04', '0'),
('bmw6666@inbox.lv', 'd9b8b45f357661769ffcd0d7f63feb9c44TrAh0885', 'jbrasari', 'avatars/new_user/no_avatar.jpg', '2011-02-12 14:08:34', '1', '2011-02-12 14:08:34', '0'),
('olyk@inbox.lv', '463731711d70d87cc37e77746de9baf044TrAh0885', 'Olyk', 'avatars/new_user/no_avatar.jpg', '2011-02-12 19:17:47', '1', '2011-02-12 19:17:47', '0'),
('tenar@inbox.lv', '4bc6e96e9ebb4fd89eef69f3b7e2039d44TrAh0885', 'tenar', 'avatars/new_user/no_avatar.jpg', '2011-02-12 23:29:01', '1', '2011-02-12 23:29:01', '0'),
('cityboss508@inbox.lv', 'a36746933b729fcb893f765dff5dbb1344TrAh0885', 'principesa', 'avatars/new_user/no_avatar.jpg', '2011-02-14 12:15:02', '1', '2011-02-14 12:15:02', '0'),
('l.uspenska@inbox.lv', '3305cf40e625d1c44b87550234ce035a44TrAh0885', 'Liza Uspenskaja', 'avatars/new_user/no_avatar.jpg', '2011-02-14 16:29:17', '1', '2011-02-14 16:29:17', '0'),
('aromawell@inbox.lv', 'a70fb54da7722a87ed79ae828ecedae444TrAh0885', 'AromaWell', 'avatars/new_user/no_avatar.jpg', '2011-02-15 13:49:35', '1', '2011-02-15 13:49:35', '0'),
('jelena.zikina@inbox.lv', '39d00c6da9d3008b77ceaa6ba71c7fe244TrAh0885', 'Lena', 'avatars/new_user/no_avatar.jpg', '2011-02-20 10:44:10', '1', '2011-02-20 10:44:10', '0'),
('opaaa07@mail.ru', '6006f2fddac5b9b4a764af970b28c03844TrAh0885', 'opaaa', 'avatars/new_user/no_avatar.jpg', '2011-02-25 01:18:07', '1', '2011-02-25 01:18:07', '0'),
('jelenalis@inbox.lv', '28333729262ec07dbe4d48ff9271419044TrAh0885', 'Jelena', 'avatars/new_user/no_avatar.jpg', '2011-02-27 12:16:45', '1', '2011-02-27 12:16:45', '0'),
('osscare@apollo.lv', 'ef3e4c266c095f32001d5f6e9ad107c844TrAh0885', 'osscare', 'avatars/new_user/no_avatar.jpg', '2011-03-09 13:12:20', '1', '2011-03-09 15:21:00', '0'),
('info@nightangel.lv', 'a36746933b729fcb893f765dff5dbb1344TrAh0885', 'resin2', 'avatars/new_user/no_avatar.jpg', '2011-03-28 19:50:17', '1', '2011-03-28 19:50:17', '0'),
('meriden1@inbox.lv', '44878fc9b8f52d19347a5701b42d5cda44TrAh0885', 'somashop', 'avatars/new_user/no_avatar.jpg', '2011-03-31 14:35:35', '1', '2011-03-31 14:35:35', '0'),
('info@bitcom.lv', '8cc0facc8880539a712f97bf5d66b4ba44TrAh0885', 'bitcom', 'avatars/new_user/no_avatar.jpg', '2011-04-11 15:42:48', '1', '2011-04-11 15:42:48', '0');
